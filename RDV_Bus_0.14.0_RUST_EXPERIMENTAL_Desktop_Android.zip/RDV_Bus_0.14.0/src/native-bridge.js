import { Capacitor, registerPlugin } from '@capacitor/core';
import { invoke } from '@tauri-apps/api/core';

// Tauri 2 exposes this internal marker in its native WebView. The public
// isTauri() helper checks window.isTauri, which is not guaranteed to be set
// in every Tauri configuration. This project already depends on the IPC
// internals for invoke(), so use the same runtime marker consistently.
const isTauriRuntime = typeof window !== 'undefined' &&
  typeof window.__TAURI_INTERNALS__ !== 'undefined';

// Desktop: a ponte Rust expõe a mesma API usada pelo plugin Android.
if (isTauriRuntime) {
  const call = (command, args = {}) => invoke(command, args);
  window.RDVDesktopApp = true;
  window.RDVNativeApp = true;
  window.RDVNativeVideo = {
    getCapabilities: () => call('desktop_get_capabilities'),
    processRenderFrame: (p) => call('desktop_process_render_frame', p),
    createVideoSession: (p) => call('desktop_create_video_session', p),
    addFrame: (p) => call('desktop_add_frame', p),
    finishVideoSession: (p) => call('desktop_finish_video_session', p),
    cancelVideoSession: (p) => call('desktop_cancel_video_session', p),
    exportVideo: (p) => call('desktop_export_video', p),
    createPackage: (p) => call('desktop_create_package', p),
    addPackageBlob: (p) => call('desktop_add_package_blob', p),
    addPackageVideo: (p) => call('desktop_add_package_video', p),
    finishPackage: (p) => call('desktop_finish_package', p),
    cancelPackage: (p) => call('desktop_cancel_package', p),
    saveBlob: (p) => call('desktop_save_blob', p),
    getDefaultOutputDirectory: () => call('desktop_get_default_output_directory'),
    chooseOutputDirectory: (p) => call('desktop_choose_output_directory', p),
    openOutputDirectory: (p) => call('desktop_open_output_directory', p)
  };
  window.RDVNativeBridgeReady = invoke('diagnose_runtime').then((report) => {
    window.RDVDesktopRuntime = report;
    window.dispatchEvent(new CustomEvent('rdv-native-runtime-diagnostic', { detail: report }));
    return report;
  }).catch((error) => {
    const message = String(error?.message || error);
    console.error('Falha no diagnóstico nativo do RDV Bus:', error);
    const report = {
      platform: 'desktop',
      ffmpeg: { available: false, detail: message },
      warnings: [message]
    };
    window.RDVDesktopRuntime = report;
    window.dispatchEvent(new CustomEvent('rdv-native-runtime-diagnostic', { detail: report }));
    return report;
  });
  window.dispatchEvent(new CustomEvent('rdv-native-bridge-ready', { detail: { native: true, desktop: true } }));
} else {
  // Android: plugin nativo registrado no MainActivity.
  const RDVNativeVideo = registerPlugin('RDVNativeVideo');
  window.RDVNativeApp = Capacitor.isNativePlatform();
  window.RDVNativeVideo = RDVNativeVideo;
  window.RDVNativeBridgeReady = Promise.resolve(true);
  window.dispatchEvent(new CustomEvent('rdv-native-bridge-ready', {
    detail: { native: window.RDVNativeApp }
  }));
}
