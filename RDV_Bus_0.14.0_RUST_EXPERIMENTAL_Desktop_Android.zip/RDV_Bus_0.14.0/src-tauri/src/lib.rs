// Biblioteca reservada para comandos nativos compartilhados do RDV Bus Desktop.
