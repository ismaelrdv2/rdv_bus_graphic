import { defineConfig } from 'vite';
import { resolve } from 'node:path';

export default defineConfig({
  root: 'src',
  base: './',
  publicDir: resolve(process.cwd(), 'public'),
  build: {
    outDir: resolve(process.cwd(), 'dist'),
    emptyOutDir: true,
    sourcemap: false,
    target: 'es2020'
  },
  server: {
    host: '127.0.0.1',
    port: 5173,
    strictPort: true
  }
});
