package com.rdvsoftware.rdvbus

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Ponte nativa do RDV Bus para o FFmpegKitNext.
 * Processa um quadro PNG por chamada e grava imediatamente no cache privado.
 * Nunca mantém a sequência inteira de quadros na RAM do app.
 */
@CapacitorPlugin(name = "RDVNativeVideo")
class RDVNativeVideoPlugin : Plugin() {

    private data class VideoJob(
        val token: String,
        val root: File,
        val framesDir: File,
        val output: File,
        val width: Int,
        val height: Int,
        val fps: Int,
        val expectedFrames: Int,
        val format: String,
        val filename: String,
        @Volatile var receivedFrames: Int = 0,
        @Volatile var ffmpegSessionId: Long? = null,
        @Volatile var ready: Boolean = false
    )

    private data class PackageItem(val name: String, val file: File)
    private data class PackageJob(
        val token: String,
        val root: File,
        val filename: String,
        val items: MutableList<PackageItem> = mutableListOf()
    )

    private val videoJobs = ConcurrentHashMap<String, VideoJob>()
    private val packageJobs = ConcurrentHashMap<String, PackageJob>()
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var encoderCaps: JSObject? = null

    override fun load() {
        super.load()
        // Remove leftovers from a previous process that may have been killed mid-export.
        val tempRoot = File(context.cacheDir, "rdv-native")
        tempRoot.listFiles()?.forEach { leftover ->
            try { leftover.deleteRecursively() } catch (_: Exception) { }
        }
    }

    private val formats = mapOf(
        "qtrle" to listOf("-c:v", "qtrle", "-pix_fmt", "argb", "-threads", "2"),
        "prores" to listOf("-c:v", "prores_ks", "-profile:v", "4444", "-vendor", "apl0", "-alpha_bits", "16", "-pix_fmt", "yuva444p10le", "-threads", "2"),
        "movpng" to listOf("-c:v", "png", "-pix_fmt", "rgba", "-threads", "2"),
        "ffv1" to listOf("-c:v", "ffv1", "-level", "3", "-pix_fmt", "bgra", "-threads", "2"),
        "vp9alpha" to listOf("-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-auto-alt-ref", "0", "-b:v", "0", "-crf", "26", "-deadline", "good", "-cpu-used", "5", "-row-mt", "1", "-threads", "2")
    )

    @PluginMethod
    fun getCapabilities(call: PluginCall) {
        val cached = encoderCaps
        if (cached != null) {
            call.resolve(JSObject(cached.toString()))
            return
        }
        io.execute {
            try {
                val session = FFmpegKit.execute("-hide_banner -encoders")
                val output = session.output ?: ""
                val isOk = ReturnCode.isSuccess(session.returnCode)
                val available = JSObject()
                available.put("qtrle", isOk && output.contains("qtrle"))
                available.put("prores", isOk && output.contains("prores_ks"))
                available.put("movpng", isOk && output.contains(" png "))
                available.put("ffv1", isOk && output.contains("ffv1"))
                available.put("vp9alpha", isOk && output.contains("libvpx-vp9"))
                val result = JSObject()
                result.put("ok", true)
                result.put("ffmpeg", isOk)
                result.put("ffmpegVersion", if (isOk) "FFmpegKitNext / FFmpeg nativo" else "FFmpeg indisponível")
                result.put("formats", available)
                result.put("message", if (isOk) "Codificação nativa disponível no dispositivo." else "Não foi possível inicializar o FFmpeg nativo.")
                encoderCaps = result
                call.resolve(JSObject(result.toString()))
            } catch (e: Exception) {
                call.reject("Falha ao verificar os codificadores nativos: ${e.message}", e)
            }
        }
    }

    @PluginMethod
    fun createVideoSession(call: PluginCall) {
        try {
            val format = call.getString("format") ?: throw IllegalArgumentException("Formato ausente.")
            if (!formats.containsKey(format)) throw IllegalArgumentException("Formato não suportado: $format")
            val width = call.getInt("width") ?: 0
            val height = call.getInt("height") ?: 0
            val fps = call.getInt("fps") ?: 0
            val count = call.getInt("frames") ?: 0
            require(width in 16..3840 && height in 16..3840 && width.toLong() * height <= 3840L * 2160L) { "Resolução inválida." }
            require(fps in listOf(24, 25, 30, 50, 60)) { "FPS inválido." }
            require(count in 1..7200) { "Quantidade de quadros inválida (máximo 7200)." }
            if (context.cacheDir.usableSpace < 256L * 1024L * 1024L) {
                throw IllegalStateException("Pouco espaço livre. Libere pelo menos 256 MB antes de iniciar a exportação.")
            }

            val token = UUID.randomUUID().toString().replace("-", "")
            val root = File(context.cacheDir, "rdv-native/video/$token")
            val framesDir = File(root, "frames")
            if (!framesDir.mkdirs()) throw IllegalStateException("Não foi possível criar o diretório temporário de quadros.")
            val filename = safeName(call.getString("filename") ?: "rdv_export${extension(format)}")
            val job = VideoJob(token, root, framesDir, File(root, filename), width, height, fps, count, format, filename)
            videoJobs[token] = job

            val result = JSObject()
            result.put("ok", true)
            result.put("token", token)
            result.put("frames", count)
            result.put("fps", fps)
            call.resolve(result)
        } catch (e: Exception) {
            call.reject(e.message ?: "Não foi possível iniciar a exportação.", e)
        }
    }

    @PluginMethod
    fun addFrame(call: PluginCall) {
        val token = call.getString("token") ?: run { call.reject("Sessão ausente."); return }
        val index = call.getInt("index") ?: -1
        val encoded = call.getString("data") ?: run { call.reject("Quadro PNG ausente."); return }
        val job = videoJobs[token] ?: run { call.reject("Sessão de vídeo não encontrada."); return }
        io.execute {
            var bytes: ByteArray? = null
            try {
                if (job.ready) throw IllegalStateException("A sessão já foi codificada.")
                if (index != job.receivedFrames) throw IllegalArgumentException("Ordem incorreta: esperado ${job.receivedFrames}, recebido $index.")
                bytes = Base64.decode(encoded.substringAfter(","), Base64.DEFAULT)
                if (bytes.size < 32 || bytes.size > 24 * 1024 * 1024) throw IllegalArgumentException("Quadro PNG vazio ou acima do limite de 24 MB.")
                if (job.root.usableSpace < bytes.size.toLong() + 64L * 1024L * 1024L) {
                    throw IllegalStateException("Espaço temporário insuficiente durante a renderização. Libere armazenamento e tente novamente.")
                }
                val signature = byteArrayOf(0x89.toByte(), 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a)
                if (!bytes.copyOfRange(0, 8).contentEquals(signature)) throw IllegalArgumentException("O quadro recebido não é um PNG válido.")
                val pngWidth = ByteBuffer.wrap(bytes, 16, 4).order(ByteOrder.BIG_ENDIAN).int
                val pngHeight = ByteBuffer.wrap(bytes, 20, 4).order(ByteOrder.BIG_ENDIAN).int
                if (pngWidth != job.width || pngHeight != job.height) throw IllegalArgumentException("Dimensões do PNG não correspondem à sessão.")

                val file = File(job.framesDir, "frame_${index.toString().padStart(6, '0')}.png")
                FileOutputStream(file).use { out -> out.write(bytes) }
                job.receivedFrames++
                val result = JSObject()
                result.put("ok", true)
                result.put("received", job.receivedFrames)
                result.put("total", job.expectedFrames)
                call.resolve(result)
            } catch (e: Exception) {
                call.reject(e.message ?: "Falha ao gravar quadro.", e)
            } finally {
                bytes?.fill(0)
            }
        }
    }

    @PluginMethod
    fun finishVideoSession(call: PluginCall) {
        val token = call.getString("token") ?: run { call.reject("Sessão ausente."); return }
        val job = videoJobs[token] ?: run { call.reject("Sessão de vídeo não encontrada."); return }
        if (job.receivedFrames != job.expectedFrames) {
            call.reject("Quadros incompletos: ${job.receivedFrames}/${job.expectedFrames}.")
            return
        }
        if (job.ready) {
            call.reject("Esta sessão já foi concluída.")
            return
        }

        val args = mutableListOf(
            "-y", "-hide_banner", "-loglevel", "error", "-framerate", job.fps.toString(),
            "-start_number", "0", "-i", File(job.framesDir, "frame_%06d.png").absolutePath,
            "-frames:v", job.expectedFrames.toString(), "-an"
        )
        args.addAll(formats[job.format]!!)
        args.add(job.output.absolutePath)
        val command = args.joinToString(" ") { quoteArgument(it) }

        try {
            val session = FFmpegKit.executeAsync(command) { completed ->
                if (ReturnCode.isSuccess(completed.returnCode) && job.output.exists() && job.output.length() > 0L) {
                    job.ready = true
                    job.framesDir.deleteRecursively()
                    val result = JSObject()
                    result.put("ok", true)
                    result.put("token", token)
                    result.put("filename", job.filename)
                    result.put("size", job.output.length())
                    result.put("codec", job.format)
                    result.put("frames", job.expectedFrames)
                    result.put("fps", job.fps)
                    call.resolve(result)
                } else {
                    val details = completed.failStackTrace ?: completed.output ?: "FFmpeg retornou código ${completed.returnCode}."
                    job.root.deleteRecursively()
                    videoJobs.remove(token)
                    call.reject("Falha na codificação: $details")
                }
            }
            job.ffmpegSessionId = session.sessionId
        } catch (e: Exception) {
            call.reject("Não foi possível iniciar o FFmpeg: ${e.message}", e)
        }
    }

    @PluginMethod
    fun cancelVideoSession(call: PluginCall) {
        val token = call.getString("token") ?: ""
        val job = videoJobs.remove(token)
        if (job != null) {
            job.ffmpegSessionId?.let { FFmpegKit.cancel(it) }
            job.root.deleteRecursively()
        }
        call.resolve(JSObject().put("ok", true))
    }

    @PluginMethod
    fun exportVideo(call: PluginCall) {
        val token = call.getString("token") ?: run { call.reject("Sessão ausente."); return }
        val job = videoJobs[token] ?: run { call.reject("Vídeo temporário não encontrado."); return }
        if (!job.ready || !job.output.exists()) { call.reject("O vídeo ainda não está pronto."); return }
        val displayName = safeName(call.getString("filename") ?: job.filename)
        val folder = safeFolder(call.getString("folder") ?: "")
        io.execute {
            try {
                val uri = publishFile(job.output, displayName, mimeFor(displayName), folder)
                val result = JSObject()
                result.put("ok", true)
                result.put("filename", displayName)
                result.put("uri", uri.toString())
                result.put("location", publicLocation(folder))
                call.resolve(result)
                job.root.deleteRecursively()
                videoJobs.remove(token)
            } catch (e: Exception) {
                call.reject("Não foi possível salvar o vídeo no dispositivo: ${e.message}", e)
            }
        }
    }

    @PluginMethod
    fun createPackage(call: PluginCall) {
        try {
            val token = UUID.randomUUID().toString().replace("-", "")
            val root = File(context.cacheDir, "rdv-native/package/$token")
            val payload = File(root, "payload")
            if (!payload.mkdirs()) throw IllegalStateException("Não foi possível criar o pacote temporário.")
            val filename = safeName(call.getString("filename") ?: "RDV_Bus_export.zip")
            packageJobs[token] = PackageJob(token, root, filename)
            call.resolve(JSObject().put("ok", true).put("token", token))
        } catch (e: Exception) {
            call.reject(e.message ?: "Não foi possível iniciar o pacote ZIP.", e)
        }
    }

    @PluginMethod
    fun addPackageBlob(call: PluginCall) {
        val token = call.getString("packageToken") ?: run { call.reject("Pacote ausente."); return }
        val job = packageJobs[token] ?: run { call.reject("Pacote não encontrado."); return }
        val name = try { safeEntryName(call.getString("name") ?: "arquivo.bin") } catch (e: Exception) {
            call.reject(e.message ?: "Nome de arquivo inválido.", e); return
        }
        val data = call.getString("data") ?: run { call.reject("Dados do arquivo ausentes."); return }
        io.execute {
            var bytes: ByteArray? = null
            try {
                bytes = Base64.decode(data.substringAfter(","), Base64.DEFAULT)
                if (bytes.size > 24 * 1024 * 1024) throw IllegalArgumentException("Arquivo individual acima do limite de 24 MB.")
                val target = File(job.root, "payload/blob_${job.items.size.toString().padStart(5, '0')}.bin")
                FileOutputStream(target).use { it.write(bytes) }
                job.items.add(PackageItem(name, target))
                call.resolve(JSObject().put("ok", true).put("count", job.items.size))
            } catch (e: Exception) {
                call.reject(e.message ?: "Falha ao adicionar arquivo ao ZIP.", e)
            } finally {
                bytes?.fill(0)
            }
        }
    }

    @PluginMethod
    fun addPackageVideo(call: PluginCall) {
        try {
            val packageToken = call.getString("packageToken") ?: throw IllegalArgumentException("Pacote ausente.")
            val videoToken = call.getString("videoToken") ?: throw IllegalArgumentException("Vídeo ausente.")
            val packageJob = packageJobs[packageToken] ?: throw IllegalArgumentException("Pacote não encontrado.")
            val videoJob = videoJobs[videoToken] ?: throw IllegalArgumentException("Vídeo temporário não encontrado.")
            if (!videoJob.ready || !videoJob.output.exists()) throw IllegalArgumentException("O vídeo ainda não foi codificado.")
            val name = safeEntryName(call.getString("name") ?: videoJob.filename)
            packageJob.items.add(PackageItem(name, videoJob.output))
            call.resolve(JSObject().put("ok", true).put("count", packageJob.items.size))
        } catch (e: Exception) {
            call.reject(e.message ?: "Não foi possível adicionar o vídeo ao ZIP.", e)
        }
    }

    @PluginMethod
    fun finishPackage(call: PluginCall) {
        val token = call.getString("packageToken") ?: run { call.reject("Pacote ausente."); return }
        val job = packageJobs[token] ?: run { call.reject("Pacote não encontrado."); return }
        if (job.items.isEmpty()) { call.reject("O pacote não contém arquivos."); return }
        io.execute {
            try {
                val zipFile = File(job.root, job.filename)
                ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zip ->
                    val buffer = ByteArray(128 * 1024)
                    for (item in job.items) {
                        zip.putNextEntry(ZipEntry(item.name))
                        BufferedInputStream(FileInputStream(item.file)).use { input ->
                            while (true) {
                                val read = input.read(buffer)
                                if (read < 0) break
                                zip.write(buffer, 0, read)
                            }
                        }
                        zip.closeEntry()
                    }
                    buffer.fill(0)
                }
                val uri = publishFile(zipFile, job.filename, "application/zip", "")
                val result = JSObject()
                result.put("ok", true)
                result.put("filename", job.filename)
                result.put("size", zipFile.length())
                result.put("uri", uri.toString())
                result.put("location", publicLocation(""))
                call.resolve(result)

                // Libera todos os vídeos temporários incluídos no pacote.
                job.items.forEach { item ->
                    videoJobs.entries.removeIf { entry ->
                        if (entry.value.output.absolutePath == item.file.absolutePath) {
                            entry.value.root.deleteRecursively()
                            true
                        } else false
                    }
                }
                job.root.deleteRecursively()
                packageJobs.remove(token)
            } catch (e: Exception) {
                call.reject("Falha ao criar o pacote ZIP: ${e.message}", e)
            }
        }
    }

    @PluginMethod
    fun cancelPackage(call: PluginCall) {
        val token = call.getString("packageToken") ?: ""
        packageJobs.remove(token)?.root?.deleteRecursively()
        call.resolve(JSObject().put("ok", true))
    }

    @PluginMethod
    fun saveBlob(call: PluginCall) {
        try {
            val relative = safeEntryName(call.getString("filename") ?: "RDV_export.png")
            val name = relative.substringAfterLast('/')
            val folder = relative.substringBeforeLast('/', "")
            val encoded = call.getString("data") ?: throw IllegalArgumentException("Dados ausentes.")
            io.execute {
                var bytes: ByteArray? = null
                val temp = File(context.cacheDir, "rdv-native/$name")
                try {
                    bytes = Base64.decode(encoded.substringAfter(","), Base64.DEFAULT)
                    if (bytes.size > 24 * 1024 * 1024) throw IllegalArgumentException("Arquivo individual acima do limite de 24 MB.")
                    temp.parentFile?.mkdirs()
                    FileOutputStream(temp).use { it.write(bytes) }
                    val uri = publishFile(temp, name, mimeFor(name), folder)
                    val result = JSObject()
                    result.put("ok", true)
                    result.put("filename", name)
                    result.put("uri", uri.toString())
                    result.put("location", publicLocation(folder))
                    call.resolve(result)
                } catch (e: Exception) {
                    call.reject("Falha ao salvar $name: ${e.message}", e)
                } finally {
                    bytes?.fill(0)
                    temp.delete()
                }
            }
        } catch (e: Exception) {
            call.reject(e.message ?: "Falha ao receber o arquivo.", e)
        }
    }

    private fun publishFile(source: File, displayName: String, mime: String, folder: String): Uri {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            throw IllegalStateException("O salvamento automático na pasta RDV Bus exige Android 10 ou superior.")
        }
        val resolver = context.contentResolver
        val subfolder = "RDV Bus/${folder}".trimEnd('/')
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$subfolder/")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        // MediaStore.Files permite publicar os vários tipos de saída no mesmo diretório RDV Bus.
        val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = resolver.insert(collection, values) ?: throw IllegalStateException("O Android não criou o arquivo de destino.")
        try {
            resolver.openOutputStream(uri, "w")?.use { output ->
                BufferedInputStream(FileInputStream(source)).use { input -> input.copyTo(output, 128 * 1024) }
            } ?: throw IllegalStateException("Não foi possível abrir o destino de gravação.")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val ready = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, ready, null, null)
            }
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    private fun publicLocation(folder: String): String =
        ("/storage/emulated/0/RDV Bus/" + folder).trimEnd('/')

    private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "mov" -> "video/quicktime"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "json" -> "application/json"
        "txt" -> "text/plain"
        "zip" -> "application/zip"
        else -> "application/octet-stream"
    }

    private fun extension(format: String): String = when (format) {
        "qtrle", "prores", "movpng" -> ".mov"
        "ffv1" -> ".mkv"
        "vp9alpha" -> ".webm"
        else -> ".mp4"
    }

    private fun safeName(value: String): String {
        val cleaned = value.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[^A-Za-z0-9._-]"), "_").trim('.', '_')
        return (cleaned.ifBlank { "rdv_export" }).take(140)
    }

    private fun safeFolder(value: String): String = value.split('/', '\\')
        .filter { it.isNotBlank() && it != "." && it != ".." }
        .joinToString("/") { safeName(it) }.take(100)

    private fun safeEntryName(value: String): String = value.split('/', '\\')
        .filter { it.isNotBlank() && it != "." && it != ".." }
        .joinToString("/") { safeName(it) }.ifBlank { "arquivo.bin" }.take(220)

    private fun quoteArgument(value: String): String = "'" + value.replace("'", "'\\''") + "'"

}
