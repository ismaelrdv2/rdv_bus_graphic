# RDV Bus 0.14.0 — Rust Renderer Experimental

> Linha experimental baseada na 0.13.6. O renderizador Rust ainda está em integração incremental; consulte `docs/RELEASE_0.14.0_RUST_RENDERER_EXPERIMENTAL.md`.

# Histórico técnico herdado da versão 0.13.6

Editor gráfico multimarcas da RDV Software, com interface compartilhada entre os aplicativos nativos Desktop (Tauri/Rust) e Android (Capacitor/Kotlin).

**Estado desta entrega:** projeto-fonte preparado; ainda não é um APK/AAB compilado, assinado ou testado em aparelho físico.

## O que já está no projeto

- Interface WebApp compartilhada, atualizada sobre a base Desktop/Android 0.12.5 em `src/index.html`.
- Patches multimarcas (RDV Bus e modelo AstroBuss), ícones adaptativos Android e licença da interface.
- Ponte JavaScript do Capacitor em `src/native-bridge.js`.
- Plugin Android em Kotlin que recebe um PNG de cada vez, grava quadros no cache privado, codifica localmente com FFmpegKitNext e publica vídeos/arquivos via MediaStore.
- Suporte configurado para MOV QTRLE, MOV ProRes 4444, MOV PNG/RGBA, MKV FFV1/BGRA e WebM VP9 com alfa, desde que o codificador correspondente esteja no build FFmpeg.
- Exportação individual e ZIP montado no próprio dispositivo.
- Script para compilar o FFmpegKitNext, preparar o projeto Android e abrir o Android Studio.

## Tecnologias

- Capacitor 8.6.0
- Vite 7
- Kotlin/Android nativo
- FFmpegKitNext 9.0.0 (compilado localmente; não há AAR binário oficial pronto para baixar)

## Requisitos para quem desenvolve

- Node.js 22 ou superior e npm.
- Java/JDK 21.
- Android Studio compatível com Capacitor 8, Android SDK Platform 36 e ferramentas de build.
- Nix (recomendado pelo FFmpegKitNext) e Git para compilar as bibliotecas FFmpeg Android.
- Espaço de armazenamento e RAM suficientes para uma compilação cruzada grande. Para reduzir a pressão de memória, o script limita o build a um job e um core por padrão. Para o primeiro teste, compila ARM64 apenas. É possível selecionar todos os ABIs com `RDV_FFMPEG_ABIS=all`. Em máquinas com pouca RAM, prefira compilar em outro computador de desenvolvimento ou em CI; a compilação nativa é uma tarefa pesada, mas isso não afeta o usuário final.

## Preparar o Android

Na raiz do projeto:

```bash
chmod +x scripts/*.sh
./scripts/prepare-android.sh
```

O script:

1. instala as dependências JavaScript;
2. compila a interface Vite;
3. cria o projeto Android do Capacitor, se ainda não existir;
4. clona a tag 9.0.0 do FFmpegKitNext;
5. compila FFmpegKitNext com Nix e habilita libvpx para VP9;
6. copia o repositório Maven local gerado para `android/ffmpegkit-maven`;
7. instala o plugin Kotlin e registra-o em `MainActivity`;
8. sincroniza o projeto Capacitor.

Depois:

```bash
npx cap open android
```

No Android Studio, aguarde a sincronização do Gradle e execute em um aparelho Android 10 ou superior. Para gerar um APK de teste use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Para distribuição, use **Build > Generate Signed Bundle / APK** e assine o AAB/APK com a chave da RDV Software.

### ABI

O padrão do build de FFmpeg é `arm64-v8a`, que atende aparelhos Android ARM64 atuais e reduz o volume da compilação. Para incluir as cinco arquiteturas do FFmpegKitNext:

```bash
RDV_FFMPEG_ABIS=all ./scripts/prepare-android.sh
```

A troca de ABI pode exigir recompilar a biblioteca nativa e aumenta bastante o tempo, o espaço em disco e o uso de memória do computador de desenvolvimento.

## Como funciona a exportação nativa

O WebView renderiza somente o quadro atual. O quadro é enviado para o plugin nativo, gravado como PNG temporário e liberado no JavaScript. Após receber a sequência, FFmpegKitNext lê os PNGs do disco e codifica o vídeo. A partir da 0.13.0, todos os resultados são publicados em `/storage/emulated/0/RDV Bus`, com subpastas internas quando necessário.

O processo evita manter a sequência inteira de imagens em RAM. Ainda assim, a codificação em Full HD/60 FPS consome CPU, memória e espaço temporário; o desempenho depende do dispositivo. Recomenda-se testar os cinco formatos nos aparelhos-alvo antes de distribuir.

## Aplicativos nativos

A interface é compartilhada entre os aplicativos Android (Capacitor/Kotlin) e Desktop (Tauri/Rust). Os recursos de instalação PWA e criação de atalho pelo navegador foram removidos desta distribuição. A execução fora dos aplicativos nativos não oferece acesso às pontes nativas de exportação.

## Plataformas futuras

A organização da interface e da ponte permite acrescentar implementações nativas para iOS, macOS, Linux e Windows. Esta entrega contém somente a ponte Android; não declara suporte nativo já concluído para as demais plataformas.

## Licenças

- Código/interface RDV Bus: MIT, conforme `LICENSE-RDV-MIT.txt`.
- FFmpegKitNext e FFmpeg: LGPL 3.0 no build padrão, sujeito às licenças dos componentes incluídos.
- `libvpx`: licença BSD; a compilação VP9 é habilitada explicitamente.
- Não habilite `--enable-gpl` nem bibliotecas GPL sem uma revisão de licenciamento antes de distribuir.
- A licença MIT da RDV Software não substitui nem altera as licenças de bibliotecas de terceiros.

Veja `THIRD_PARTY_NOTICES.md` e `docs/LICENSING.md` antes de distribuir.

## Desktop 0.12.5 — ponte Tauri/Rust e correção de inicialização

A pasta `src-tauri/` contém a implementação Desktop Tauri 2. A ponte Rust oferece sessões de vídeo quadro a quadro, codificação FFmpeg, exportação individual e montagem de ZIP. Esta versão mantém a correção da detecção do ambiente Tauri 2 e remove a gravação WebM pelo navegador. O único caminho de exportação WebM é agora o encoder VP9 com transparência via FFmpeg.

No Desktop 0.12.5, o FFmpeg é uma dependência opcional do sistema: tanto builds de desenvolvimento quanto versões Release procuram `ffmpeg` no `PATH` ou aceitam o caminho definido em `RDV_FFMPEG_PATH`. O FFmpeg não é incorporado ao AppImage nem ao instalador Windows. Sem ele, PNG estático e sequência PNG continuam disponíveis; os formatos de vídeo FFmpeg exibem instruções de instalação. Consulte `docs/RELEASE_0.12.5.md`, `docs/DESKTOP_DIAGNOSTICS.md` e `docs/BUILD_APPIMAGE_DEBIAN12.md`.

O pacote é código-fonte para desenvolvimento e testes; não é um instalador compilado. O Desktop precisa ser testado localmente, e o Android ainda precisa ser compilado e validado em aparelho físico.


## RDV Bus 0.13.0 — saída configurável e geração por abas

- **Gerar desta aba** grava os arquivos sem compactação, dentro de uma pasta do projeto no diretório de saída.
- **Gerar todas as abas** cria um único ZIP, com uma subpasta por aba.
- No Desktop, o destino padrão é a pasta Downloads do usuário; é possível escolher outro diretório e abrir o destino pelo próprio aplicativo. A escolha fica salva localmente.
- No Android, os arquivos são publicados em `/storage/emulated/0/RDV Bus`, inclusive vídeos e ZIPs.
- O Desktop utiliza o seletor nativo de pastas do Tauri (`tauri-plugin-dialog`).

O arquivo de origem 0.12.5 permanece como referência estável. Para a primeira compilação 0.13.0, regenere os arquivos de lock conforme `docs/RELEASE_0.13.0.md` antes de usar `npm ci`.


## RDV Bus 0.13.6 — retorno integral ao Canvas 2D

- Reverte integralmente a experiência SVG/resvg introduzida nas versões 0.13.2–0.13.4.
- Restaura o caminho de desenho Canvas 2D usado na versão 0.11 e mantido na base 0.13.0.
- Mantém `ANIM_SS = 2`, o cache limitado a dois itens e a composição por `drawImage()` do motor Canvas.
- Remove `@resvg/resvg-wasm`, `resvg-runtime.js` e a etapa de rasterização SVG/WASM.
- Mantém o pipeline de quadros PNG para Desktop e Android e os codificadores FFmpeg existentes.
- Não reduz resolução nem qualidade como medida de economia de memória; a remoção das camadas SVG e buffers de rasterização elimina etapas e alocações adicionais.
- Versões alinhadas: Tauri/Cargo/npm 0.13.6 e Android `versionName 0.13.6`, `versionCode 1306`.

Esta é uma versão de teste. A qualidade visual e o pico de RAM ainda precisam ser comparados no mesmo projeto e nas mesmas configurações usados para validar a 0.13.4.


## RDV Bus 0.13.6 — restauração do pipeline de geração 0.11

A geração de vídeo volta ao modelo de saída da versão 0.11: um Canvas 2D de dimensões finais é criado uma única vez e reutilizado em todos os quadros. `RDV.animationFrame` recebe esse Canvas como `target`; os quadros são codificados como PNG e enviados individualmente ao backend FFmpeg ou ao plugin nativo Android. Não é criado um novo Canvas de saída por quadro. O restante da interface e os recursos Desktop/Android da linha 0.13.x são preservados.

A alteração restaura a arquitetura do pipeline, mas não constitui confirmação de que o serrilhamento foi corrigido: isso depende do teste visual com o mesmo projeto, resolução, FPS e encoder.
