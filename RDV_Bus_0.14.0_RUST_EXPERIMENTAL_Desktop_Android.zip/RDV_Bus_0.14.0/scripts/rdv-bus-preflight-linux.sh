#!/usr/bin/env bash
# Pré-verificação para distribuições Linux. Use este iniciador ao lado do AppImage.
set -u
APPIMAGE="${1:-}"
missing=()
for lib in libwebkit2gtk-4.1.so.0 libjavascriptcoregtk-4.1.so.0 libgtk-3.so.0; do
  if ! ldconfig -p 2>/dev/null | grep -Fq "$lib"; then
    missing+=("$lib")
  fi
done
if ((${#missing[@]})); then
  msg="O RDV Bus Desktop 0.14.0 não pode iniciar porque faltam bibliotecas do sistema:\n\n"
  for lib in "${missing[@]}"; do msg+="• $lib\n"; done
  msg+="\nInstale o runtime WebKitGTK 4.1 e GTK 3 fornecido pela sua distribuição e tente novamente."
  if command -v zenity >/dev/null 2>&1; then
    zenity --error --title="RDV Bus — dependência ausente" --text="$msg" 2>/dev/null || true
  elif command -v kdialog >/dev/null 2>&1; then
    kdialog --error "$msg" --title "RDV Bus — dependência ausente" 2>/dev/null || true
  else
    printf '%b\n' "$msg" >&2
  fi
  exit 1
fi
if [[ -z "$APPIMAGE" ]]; then
  echo "Uso: $0 /caminho/para/RDV-Bus.AppImage" >&2
  exit 2
fi
if [[ ! -x "$APPIMAGE" ]]; then
  echo "O arquivo AppImage não existe ou não é executável: $APPIMAGE" >&2
  exit 3
fi
exec "$APPIMAGE" "$@"
