#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

for cmd in node npm git; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "ERRO: '$cmd' não encontrado." >&2; exit 1; }
done
NODE_MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])')"
if (( NODE_MAJOR < 22 )); then echo 'ERRO: Capacitor 8 exige Node.js 22 ou superior.' >&2; exit 1; fi

if [[ ! -d node_modules ]]; then npm install; else npm install; fi
npm run build

if [[ ! -d android ]]; then
  npx cap add android
fi

# Build and stage the LGPL FFmpegKitNext AAR (the binaries are built locally).
bash scripts/build-ffmpegkitnext-android.sh
python3 scripts/apply-android-project.py
npx cap sync android

echo
cat <<'MSG'
Projeto Android preparado.

Próximos passos:
  npx cap open android

No Android Studio:
  1. Aguarde o Gradle sincronizar.
  2. Execute no dispositivo com Run.
  3. Para APK de teste: Build > Build Bundle(s) / APK(s) > Build APK(s).
  4. Para distribuição: Build > Generate Signed Bundle / APK.

O AAR FFmpegKitNext é local ao projeto. Não remova android/ffmpegkit-maven.
MSG
