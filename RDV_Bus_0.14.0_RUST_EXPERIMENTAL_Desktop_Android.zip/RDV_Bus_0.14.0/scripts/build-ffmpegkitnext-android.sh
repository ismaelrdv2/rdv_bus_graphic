#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENDOR="$ROOT/vendor/ffmpeg-kit-next"
TAG="${FFMPEGKITNEXT_TAG:-9.0.0}"

if ! command -v git >/dev/null 2>&1; then echo 'ERRO: instale git.' >&2; exit 1; fi
if ! command -v nix >/dev/null 2>&1; then
  cat >&2 <<'MSG'
ERRO: Nix não foi encontrado.
O FFmpegKitNext é distribuído como código-fonte e precisa ser compilado.
Instale o Nix no computador de desenvolvimento e execute novamente.
Documentação: https://github.com/arthenica/ffmpeg-kit-next/blob/main/android/README.md
MSG
  exit 1
fi

mkdir -p "$ROOT/vendor"
if [[ ! -d "$VENDOR/.git" ]]; then
  echo "Clonando FFmpegKitNext $TAG…"
  git clone --filter=blob:none --branch "$TAG" --depth 1 https://github.com/arthenica/ffmpeg-kit-next.git "$VENDOR"
else
  git -C "$VENDOR" fetch --tags --depth 1 origin "$TAG"
  git -C "$VENDOR" checkout --detach "$TAG"
fi

cd "$VENDOR"
ARGS=(-p android-r27d --enable-lib-vpx)
case "${RDV_FFMPEG_ABIS:-arm64}" in
  arm64)
    # Build for current Android phones first; this keeps the native build smaller.
    ARGS+=(--disable-arch-arm-v7a --disable-arch-arm-v7a-neon --disable-arch-x86 --disable-arch-x86_64)
    ;;
  all)
    ;;
  *) echo 'RDV_FFMPEG_ABIS deve ser arm64 ou all.' >&2; exit 2 ;;
esac

echo "Compilando FFmpegKitNext $TAG para Android (ABIs: ${RDV_FFMPEG_ABIS:-arm64})…"
NIX_BUILD_CORES="${NIX_BUILD_CORES:-1}" NIX_MAX_JOBS="${NIX_MAX_JOBS:-1}" ./nix-android.sh "${ARGS[@]}"

REPO="$VENDOR/prebuilt/bundle-android-aar-24-maven"
if [[ ! -d "$REPO/com/arthenica/ffmpeg-kit-next/$TAG" ]]; then
  echo "ERRO: o repositório Maven esperado não foi produzido em: $REPO" >&2
  echo 'Confira a pasta prebuilt e a versão do artefato gerado.' >&2
  exit 1
fi

mkdir -p "$ROOT/android/ffmpegkit-maven"
rm -rf "$ROOT/android/ffmpegkit-maven"/*
cp -a "$REPO"/. "$ROOT/android/ffmpegkit-maven"/
echo "Repositório Maven local instalado em android/ffmpegkit-maven."
