package com.rdvsoftware.rdvbus;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

/** Registers the RDV Bus native FFmpeg bridge before the WebView is created. */
public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(RDVNativeVideoPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
