# RDV Bus 0.14.0 — compilação experimental no Linux

Esta versão requer Node.js/npm, Rust/Cargo, dependências de sistema do Tauri 2 e FFmpeg para exportação de vídeo. A dependência `image` do Rust será baixada pelo Cargo.

```bash
# Debian/Ubuntu: instale antes as dependências Tauri 2 e WebKitGTK
# CachyOS/Arch: instale as dependências Tauri 2 equivalentes
cd RDV_Bus_0.14.0
npm install
npm run desktop:build -- --bundles appimage
```

Para executar em modo de desenvolvimento: `npm run desktop:dev`.

A compilação ainda precisa gerar `Cargo.lock` e `package-lock.json` no primeiro `npm install`/build caso não estejam presentes no pacote. Guarde os lockfiles resultantes junto à árvore de fontes para reproduzir os testes.

O renderer experimental Rust é chamado por Tauri apenas no Desktop. A versão Android e o navegador usam fallback Canvas nesta etapa; não use esses targets para concluir se o core Rust está validado.

Em 4K + superamostragem, o buffer intermediário pode chegar a 7680×4320 em paisagem. Recomenda-se começar com 1080p nativo, depois 1080p superamostrado e só então 4K.
