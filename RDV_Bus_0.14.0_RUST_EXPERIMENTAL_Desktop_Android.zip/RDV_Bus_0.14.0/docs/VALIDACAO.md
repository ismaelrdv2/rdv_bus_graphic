# Estado da validação — RDV Bus 0.12.5 alfa

## Alterações incluídas
- Removida a opção de WebM por captura do navegador e seu caminho `MediaRecorder`.
- Mantido WebM VP9 com transparência por FFmpeg.
- Ajustes antigos com `formato: "webm"` migram para `vp9alpha` ao abrir.
- Mantida a ponte Tauri 2/Rust corrigida na versão 0.12.3.
- Versões Desktop/Android alinhadas em 0.12.5; Android `versionCode 1205`.
- Capacitor permanece em 8.6.0 e FFmpegKitNext em 9.0.0.

## Verificações estáticas executadas
- Conferir JSON dos metadados de build.
- Conferir sintaxe JavaScript do bridge e dos scripts inline da interface.
- Conferir sintaxe Python e shell dos scripts.
- Confirmar que não restam referências executáveis a `MediaRecorder`, `recordWebM` ou ao controle de FPS do WebM do navegador.
- Conferir consistência das versões.

## Testes ainda necessários
- Testar `npm run desktop:dev` no CachyOS com FFmpeg instalado e repetir exportações de vídeo.
- Compilar e executar o AppImage sem FFmpeg instalado; confirmar que o aplicativo abre, gera PNG e sequência PNG e informa como instalar FFmpeg ao solicitar vídeo.
- Compilar e executar AppImage em Debian 12.
- Testar o AppImage com FFmpeg do sistema instalado e validar os cinco encoders e a transparência.
- Compilar Android, instalar e testar em aparelho físico; o Android ainda não foi validado nesta sequência.

Esta entrega é um pacote-fonte. As verificações estáticas não equivalem a builds nativos ou testes de runtime.


## 0.13.0 — alterações implementadas, aguardando validação de runtime

- Geração individual sem ZIP.
- Geração de todas as abas em ZIP com subpastas por aba.
- Diretório de saída configurável no Desktop, padrão Downloads, com ação para abrir a pasta.
- Android direcionado à pasta pública `/storage/emulated/0/RDV Bus`.
- A compilação e os testes de runtime da 0.13.0 ainda precisam ser executados; a validação 0.12.5 não deve ser atribuída automaticamente a esta versão.
