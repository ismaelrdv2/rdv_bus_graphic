# Checklist de distribuição alfa

- [ ] Compilar o FFmpegKitNext com a versão e configurações fixadas.
- [ ] Guardar logs de build e a configuração completa de FFmpeg.
- [ ] Conferir a presença dos encoders: `qtrle`, `prores_ks`, `png`, `ffv1`, `libvpx-vp9`.
- [ ] Testar transparência real (alfa 0 e 255) em cada formato.
- [ ] Testar exportação PNG, arquivo individual e ZIP.
- [ ] Testar quadros incompletos, cancelamento, pouco espaço em disco e encerramento do app durante codificação.
- [ ] Testar 1080p/60 FPS em aparelhos ARM64 com diferentes capacidades de RAM.
- [ ] Validar a cópia de quadros um a um e a limpeza do cache temporário.
- [ ] Verificar ABI e alinhamento de páginas nativas de 16 KB no APK/AAB final.
- [ ] Testar o app sem conexão com internet após a instalação.
- [ ] Conferir licenças de FFmpeg, FFmpegKitNext, libvpx, Capacitor e demais dependências.
- [ ] Preparar chave de assinatura, política de privacidade e informações da loja.
- [ ] Testar em pelo menos dois aparelhos Android físicos antes de declarar a versão estável.
