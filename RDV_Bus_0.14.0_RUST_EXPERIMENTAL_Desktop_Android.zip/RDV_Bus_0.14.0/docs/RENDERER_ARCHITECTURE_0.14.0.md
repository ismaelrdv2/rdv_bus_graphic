# Arquitetura experimental do renderizador — 0.14.0

## Fluxo atual

```text
Configuração e composição
        ↓
Canvas de composição (escala física selecionável)
        ↓ PNG intermediário
Comando Tauri / Rust: desktop_process_render_frame
        ↓ (somente superamostragem no Desktop)
image-rs: Lanczos3 / Catmull-Rom / Triangle
        ↓ PNG na dimensão final
Sessão de quadros nativa
        ↓
FFmpeg local
```

A interface continua em HTML/JavaScript. O desenho de cada elemento ainda é feito pelo renderizador Canvas existente; o avanço desta versão é tornar a escala de rasterização configurável e introduzir uma etapa CPU em Rust para redução de superamostragem no Desktop. Isso é uma etapa intermediária, não a substituição completa do motor por Skia.

## Perfis

| Opção | Escala interna relativa à saída | Filtro Rust |
|---|---:|---|
| Nativa | 1× | não há redução |
| Superamostragem · qualidade máxima | 2× | Lanczos3 |
| Superamostragem · equilibrada | 1,5× | Catmull-Rom |
| Superamostragem · desempenho | 1,25× | Triangle |

A resolução final pode ser Full HD ou 4K. Em retrato, largura e altura são invertidas automaticamente. A prioridade também ajusta a resolução dos elementos intermediários de animação no modo nativo.

## Próxima etapa

Comparar quadros idênticos da 0.11, 0.13.6 e 0.14.0. Só depois de validar a qualidade e os custos de RAM/tempo deve-se substituir o desenho de primitivas pelo backend de desenho Rust (por exemplo, Skia CPU). Não assumir que a simples troca de biblioteca corrige serrilhamento: coordenadas, alinhamento subpixel, dimensões e transformações também precisam ser auditados.
