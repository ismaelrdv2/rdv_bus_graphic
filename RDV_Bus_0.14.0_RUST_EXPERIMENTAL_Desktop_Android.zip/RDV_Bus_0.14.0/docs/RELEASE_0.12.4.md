# RDV Bus 0.12.4 — WebM VP9 único e preparação AppImage

## Alterações
- Removida da interface a opção **WebM — captura do navegador**.
- Removido o caminho de gravação baseado em `MediaRecorder` e `canvas.captureStream()`.
- Mantido **WebM VP9 com transparência via FFmpeg** (`libvpx-vp9`), que é o caminho WebM validado no Desktop.
- Mantidos MOV QTRLE, MOV ProRes 4444, MOV PNG/RGBA, MKV FFV1/BGRA e sequência PNG.
- Projetos/ajustes antigos que tinham `formato: "webm"` são migrados automaticamente para `vp9alpha` ao abrir.
- Capacitor permanece em 8.6.0 e FFmpegKitNext permanece em 9.0.0; não foram alteradas dependências.
- Versões Desktop/Android atualizadas para `0.12.4`; Android `versionCode 1204`.

## Preparação de AppImage
- Incluído `docs/BUILD_APPIMAGE_DEBIAN12.md` com o roteiro de compilação de teste em Debian 12.
- O AppImage continua dependendo do runtime WebKitGTK 4.1/GTK do sistema; não é um pacote que carrega o WebKitGTK inteiro.
- O pacote-fonte não inclui binários FFmpeg. Para exportação de vídeo em uma compilação release, é necessário preparar um FFmpeg estático, revisado quanto a codecs e licenças, em `src-tauri/resources/ffmpeg/linux-x86_64/ffmpeg`.
- Para uma primeira prova de empacotamento/abertura, é possível compilar sem FFmpeg; nesse caso, PNG funciona, mas os formatos de vídeo FFmpeg não estarão disponíveis.

## Estado dos testes
Esta entrega foi submetida a verificações estáticas do pacote-fonte. Ainda não equivale a um build Tauri/AppImage executado nem a testes em Debian 12 ou Android físico. Validar no ambiente de compilação antes de considerar a versão aprovada.
