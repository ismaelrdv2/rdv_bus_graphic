# RDV Bus 0.13.0 — gerenciamento de saída

## Mudanças

- Removida a escolha de formato ZIP/individual.
- `Gerar desta aba`: grava os arquivos individualmente, sem compactação.
- `Gerar todas as abas`: cria um único ZIP com uma subpasta para cada aba.
- Nova seção de diretório de saída no Desktop, exibindo o destino atual, permitindo selecionar outra pasta e abrir a pasta escolhida.
- Diretório padrão Desktop: pasta Downloads resolvida pelo sistema operacional (Linux: normalmente `~/Downloads`; Windows: `%USERPROFILE%\Downloads`).
- Diretório padrão Android: `/storage/emulated/0/RDV Bus`, compartilhado entre imagens, sequências, vídeos e pacotes ZIP.
- A seleção do diretório Desktop é persistida nas configurações locais do aplicativo. O projeto Android será gerado com `versionName 0.13.0` e `versionCode 1300`.

## Dependência Desktop adicional

Foi adicionado `tauri-plugin-dialog` 2.x para abrir o seletor nativo de diretórios no Linux e Windows. O plugin usa GTK 3 no Linux por padrão; o ambiente Debian 12 preparado para o projeto já possui as dependências GTK/WebKitGTK necessárias.

## Preparação inicial dos arquivos de lock

O ZIP de origem 0.12.5 não continha `package-lock.json` nem `src-tauri/Cargo.lock`. Se você ainda tem a pasta estável 0.12.5 no Debian, copie os dois lockfiles para a pasta 0.13.0 antes de instalar:

```bash
cp ../RDV_Bus_0.12.5/package-lock.json ./package-lock.json
cp ../RDV_Bus_0.12.5/src-tauri/Cargo.lock ./src-tauri/Cargo.lock
npm install --package-lock-only --ignore-scripts
npm ci
```

O `npm install --package-lock-only` atualiza o lockfile raiz para a versão 0.13.0 sem descartar as versões resolvidas anteriormente. Na primeira compilação Tauri, o Cargo acrescenta `tauri-plugin-dialog` e atualiza `src-tauri/Cargo.lock`. Se você não tiver os lockfiles antigos, use `npm install` e `(cd src-tauri && cargo generate-lockfile)` em vez da cópia. Aprove os scripts npm necessários conforme a política local (por exemplo, `npm install-scripts approve esbuild` se o npm bloquear o esbuild).

## Validação pendente

A alteração foi revisada estaticamente, mas ainda não foi compilada nem testada em runtime nesta sessão. Antes de distribuir, validar: PNG individual, PNG sequence individual, todos os cinco formatos FFmpeg individualmente, ZIP de todas as abas com arquivos e sequências, escolha de diretório, persistência após reinício e botão Abrir pasta no Debian 12 e Fedora 44. Android deve ser testado separadamente para confirmar a publicação na pasta pública desejada.
