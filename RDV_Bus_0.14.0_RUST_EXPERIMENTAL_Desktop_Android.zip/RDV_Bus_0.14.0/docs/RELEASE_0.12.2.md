# RDV Bus 0.12.2 — Implementação da ponte de codecs

## Alterações
- Ponte de vídeo Desktop em Rust/Tauri compatível com a API do plugin Android.
- Sessões de vídeo recebem e gravam PNGs quadro a quadro no cache privado; FFmpeg codifica a sequência a partir do disco.
- Formatos implementados: MOV QTRLE/ARGB, MOV ProRes 4444, MOV PNG/RGBA, MKV FFV1/BGRA e WebM VP9 com alfa.
- ZIP e exportação individual integrados à ponte Desktop. PNG estático e sequência PNG preservados.
- FFmpeg desktop resolvido por recurso do aplicativo; fallback para FFmpeg do sistema existe somente em desenvolvimento.
- FFmpegKitNext Android atualizado para a release oficial 9.0.0. O projeto não deve usar a tag 9.0.2: ela aparece em aplicações de teste, enquanto a release de código-fonte indicada pelo repositório principal é 9.0.0.
- Capacitor mantido em 8.6.0.

## Atenção: artefatos nativos ainda precisam ser produzidos
Esta versão contém o código de integração, mas o pacote de código-fonte não contém binários FFmpeg. Para testes Desktop, aponte `RDV_FFMPEG_PATH` para um FFmpeg com os cinco encoders. Para compilar instaladores independentes, coloque binários estáticos e licenciados em `src-tauri/resources/ffmpeg/linux-x86_64/ffmpeg` e `windows-x86_64/ffmpeg.exe` antes de executar `tauri build`.

No Android, execute `npm run android:prepare` para compilar o AAR local FFmpegKitNext 9.0.0 com `--enable-lib-vpx`, sincronizar o plugin e preparar o Gradle. O APK/AAB final ainda precisa ser compilado e testado em dispositivo real.

## Testes necessários
- Consultar capacidades e confirmar os cinco encoders em cada plataforma.
- Exportar um vídeo de teste com transparência e verificar o canal alfa em cada formato.
- Testar ZIP e exportação individual, cancelamento, pouco espaço e falha de codificação.
- Confirmar que o arquivo é reproduzível nos editores de vídeo de destino.

## Validação técnica preliminar dos comandos FFmpeg

Foi gerada uma sequência curta de PNGs RGBA e executada a codificação dos cinco formatos com FFmpeg 7.1.5 no ambiente de desenvolvimento. Os arquivos foram reconhecidos pelo ffprobe:
- QTRLE: `argb`
- ProRes 4444: `yuva444p12le` (o encoder converteu para 12 bits)
- MOV PNG: `rgba`
- FFV1: `bgra`
- VP9: metadado WebM `alpha_mode=1` (o ffprobe reporta o plano principal como `yuv420p`)

Isso valida os parâmetros e a disponibilidade desses encoders nessa compilação específica do FFmpeg; não substitui o teste do FFmpegKitNext 9.0.0 no Android nem a compilação do backend Rust/Tauri, que ainda precisa ser feita no ambiente de desenvolvimento com Cargo.
