# Compilação Android

Requisitos do ambiente de desenvolvimento: Node.js 22+, JDK 21, Android SDK/NDK conforme o perfil FFmpegKitNext e Nix em host suportado. O usuário final não instala Nix, Python, FFmpeg ou Node.

Execute `npm run android:prepare`. O script compila localmente FFmpegKitNext 9.0.0 pelo perfil `android-r27d`, habilita `libvpx` e integra o AAR gerado no repositório Maven local. A versão 9.0.0 é a release de código-fonte publicada pelo projeto principal; 9.0.2 corresponde a uma tag de aplicações de teste, não à release principal do FFmpegKitNext.

Os encoders internos esperados são `qtrle`, `prores_ks`, `png` e `ffv1`; `libvpx-vp9` depende de `--enable-lib-vpx`. A disponibilidade é consultada em tempo de execução.

Depois da preparação, abra `android/` no Android Studio, sincronize o Gradle e compile APK/AAB. Teste os cinco formatos em aparelho real antes de distribuir.
