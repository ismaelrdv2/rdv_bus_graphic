# Compilação de teste do RDV Bus 0.13.6 — AppImage (Debian 12)

Este roteiro é para o computador separado com **Debian 12 Bookworm x86_64**. Mantenha o CachyOS como ambiente de desenvolvimento e testes diários. O AppImage deve ser compilado na base Linux mais antiga que se pretende suportar; a documentação Tauri indica Debian 12 como uma base adequada para Tauri 2 com WebKitGTK 4.1.

> Importante: AppImage não torna o RDV Bus totalmente independente do sistema. O Tauri usa WebKitGTK 4.1 e GTK 3 do sistema hospedeiro. O AppImage empacota a aplicação e seus recursos, mas o runtime WebKitGTK continua sendo uma dependência do Linux de destino.

## 1. Atualizar o Debian e instalar dependências

Abra o terminal:

```bash
sudo apt update
sudo apt full-upgrade -y
sudo apt install -y \
  build-essential \
  curl wget file pkg-config \
  libwebkit2gtk-4.1-dev \
  libxdo-dev \
  libssl-dev \
  libayatana-appindicator3-dev \
  librsvg2-dev \
  git unzip xz-utils \
  libfuse2
```

`libfuse2` é útil para executar AppImages que usam FUSE 2. Se a execução por FUSE não estiver disponível, algumas AppImages permitem extração com `--appimage-extract`.

Confirme que WebKitGTK 4.1 foi instalado:

```bash
pkg-config --modversion webkit2gtk-4.1
```

## 2. Instalar/confirmar Node.js e Rust

O projeto requer Node.js 22 ou superior, npm e Rust stable. No computador de desenvolvimento já foi utilizado Node.js 26; mantenha uma versão compatível e atualizada também no Debian.

```bash
node --version
npm --version
rustc --version
cargo --version
```

Se Rust ainda não estiver instalado, use o instalador oficial do rustup:

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source "$HOME/.cargo/env"
rustup default stable
rustup target add x86_64-unknown-linux-gnu
```

Feche e reabra o terminal, se necessário, e confirme os comandos acima.

## 3. Extrair o projeto

Copie `RDV_Bus_0.13.6_PIPELINE_011_Desktop_Android.zip` para o Debian. Por exemplo, se estiver em Downloads:

```bash
cd ~/Downloads
unzip RDV_Bus_0.13.6_PIPELINE_011_Desktop_Android.zip
cd RDV_Bus_0.13.6
```

O nome da pasta pode variar conforme o local em que o ZIP for extraído; entre na pasta que contém `package.json` e `src-tauri/`.

## 4. Instalar dependências JavaScript

```bash
npm install
(cd src-tauri && cargo generate-lockfile)
```

A primeira geração do lockfile Cargo inclui o novo `tauri-plugin-dialog` 2.x. Guarde `package-lock.json` e `src-tauri/Cargo.lock` para os próximos builds. O projeto mantém Capacitor CLI/Core/Android alinhados em 8.6.0. Não atualize pacotes durante este teste. Se você tiver um `package-lock.json` da 0.12.3, copie-o para a raiz desta versão antes de executar `npm install`; isso ajuda a manter as mesmas versões resolvidas. Se não tiver, `npm install` criará um novo lockfile: guarde-o para repetir builds com as mesmas dependências. Não execute `npm update` nem aceite atualizações de dependências como parte deste teste. Se o npm informar vulnerabilidades ou alterações inesperadas, pare e confira o relatório.

## 5. Primeira compilação de empacotamento

Esta etapa verifica se o Tauri/Rust, o frontend e o empacotamento AppImage compilam. O ZIP-fonte não carrega o executável FFmpeg. Se o FFmpeg já estiver instalado no Debian e disponível no `PATH`, os formatos de vídeo compatíveis também poderão funcionar; caso contrário, o aplicativo abre normalmente e mantém PNG estático e sequência PNG disponíveis.

```bash
npm run desktop:build -- --bundles appimage
```

O Tauri executa `npm run build` automaticamente antes da compilação nativa. O alvo AppImage está configurado no projeto. O comando acima limita esta compilação ao AppImage, sem tentar gerar o instalador Windows NSIS no Linux.

O artefato deve aparecer em:

```text
src-tauri/target/release/bundle/appimage/
```

Localize-o sem presumir o nome exato:

```bash
find src-tauri/target/release/bundle/appimage -maxdepth 1 -type f -name '*.AppImage' -print
```

## 6. Executar a AppImage de teste

Substitua o caminho pelo nome que o comando `find` mostrou:

```bash
chmod +x src-tauri/target/release/bundle/appimage/*.AppImage
./src-tauri/target/release/bundle/appimage/*.AppImage
```

Teste pelo menos:
- inicialização e fechamento do aplicativo;
- interface, prévias e abas;
- exportação PNG estática;
- persistência dos ajustes após fechar e abrir novamente.

Se o AppImage não abrir, execute pelo terminal para preservar a mensagem de erro. Confirme também as bibliotecas WebKitGTK 4.1/GTK no Debian. O AppImage não substitui essas bibliotecas do sistema.

## 7. Instalar FFmpeg do sistema para testar exportação de vídeo

Para o Desktop 0.13.5, o FFmpeg não é empacotado. O aplicativo procura `ffmpeg` no `PATH` do sistema em builds de desenvolvimento e Release.

No Debian 12, instale com:

```bash
sudo apt install ffmpeg
```

Para validar o aplicativo sem FFmpeg, não instale essa dependência (ou teste em uma máquina limpa): o RDV Bus deve abrir normalmente, gerar PNG e sequência PNG e orientar a instalação quando um formato de vídeo FFmpeg for solicitado.

Os codificadores necessários são `qtrle`, `prores_ks`, `png`, `ffv1` e `libvpx-vp9`. A disponibilidade depende da compilação FFmpeg instalada.
## 8. Checklist para devolver os resultados

- [ ] A compilação `npm run desktop:build -- --bundles appimage` terminou sem erro.
- [ ] O arquivo `.AppImage` foi criado em `src-tauri/target/release/bundle/appimage/`.
- [ ] O aplicativo abriu no Debian 12.
- [ ] PNG estático foi exportado corretamente.
- [ ] FFmpeg instalado no sistema foi detectado (após a etapa 7).
- [ ] MOV QTRLE, MOV ProRes 4444, MOV PNG/RGBA, MKV FFV1 e WebM VP9 foram testados.
- [ ] ZIP e exportação individual foram testados.
- [ ] O AppImage foi executado pelo terminal e não apresentou dependências inesperadas.

Guarde o log completo da compilação. Se falhar, envie as últimas 80–120 linhas do terminal e o resultado de `pkg-config --modversion webkit2gtk-4.1`, `node --version`, `npm --version` e `rustc --version`.
