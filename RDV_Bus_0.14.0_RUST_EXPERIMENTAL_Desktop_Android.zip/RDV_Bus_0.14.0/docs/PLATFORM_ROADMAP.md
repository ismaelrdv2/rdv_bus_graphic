# Roteiro multiplataforma

Esta entrega inicia pela plataforma Android para validar a interface nativa, o gerenciamento de quadros no armazenamento privado e os cinco encoders com alfa.

## Android — nesta entrega

Capacitor 8 + plugin Kotlin + FFmpegKitNext 9.0.0. A codificação é local no aparelho. O pacote-fonte inclui scripts para compilar as bibliotecas Android e integrar a ponte nativa.

## iOS / iPadOS — etapa futura

Reutilizar a interface e implementar uma ponte Swift/Capacitor. Compilar FFmpegKitNext com o perfil iOS correspondente e integrar os frameworks/XCFrameworks gerados. Exige macOS e Xcode para compilar, assinar e distribuir.

## Windows / macOS / Linux — etapas futuras

Reutilizar a interface e implementar uma camada de exportação nativa por plataforma. FFmpegKitNext oferece caminhos de compilação próprios para desktop, mas cada integração, instalador e mecanismo de armazenamento ainda precisa ser construído e testado.

A existência da mesma interface web não significa que as camadas nativas dessas plataformas já estejam prontas nesta versão.
