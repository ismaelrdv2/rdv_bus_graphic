# Licenciamento antes da distribuição

## RDV Software

O código da interface e do aplicativo desenvolvido pela RDV Software é oferecido sob MIT, conforme `LICENSE-RDV-MIT.txt`, exceto ativos ou componentes de terceiros identificados em seus próprios avisos.

## FFmpegKitNext / FFmpeg

FFmpegKitNext declara LGPL 3.0 como licença padrão e GPL v3 se bibliotecas licenciadas sob GPL forem habilitadas. O build deste projeto não passa `--enable-gpl`. A opção `--enable-lib-vpx` habilita libvpx e não é uma opção GPL.

Antes de distribuir um APK/AAB:

1. inclua os textos de licença do FFmpegKitNext, FFmpeg e de todas as bibliotecas efetivamente compiladas;
2. preserve os avisos de copyright e disponibilize o código-fonte correspondente, conforme as obrigações da LGPL aplicáveis;
3. mantenha as bibliotecas FFmpeg como bibliotecas substituíveis/compartilhadas e não as mescle estaticamente ao aplicativo sem revisão jurídica;
4. registre as opções completas de configuração do FFmpeg e a lista de bibliotecas usadas;
5. revise obrigações de patentes de codecs nos países de distribuição. Este documento não é aconselhamento jurídico.

Não distribua o aplicativo como exclusivamente MIT: os componentes nativos possuem licenças próprias.
