# RDV Bus 0.12.3 — Correção da ponte nativa e diagnóstico

## Correções
- Corrigida a detecção do ambiente Tauri 2: a ponte JavaScript verifica `window.__TAURI_INTERNALS__` em vez de depender de `isTauri()`/`window.isTauri`.
- A ponte Rust/Tauri passa a ser inicializada corretamente no Desktop quando executada dentro do WebView nativo.
- Removidos alertas de diagnóstico que podiam não aparecer no WebView; erros de consulta do FFmpeg são registrados no Console e apresentados no status de exportação.
- A consulta de capacidades aguarda a inicialização da ponte nativa e preserva a mensagem original do backend quando há falha.
- `devUrl` do Tauri alinhado a `127.0.0.1`, o mesmo host usado pelo Vite, para evitar divergência de host na conexão HMR.
- Versão Android atualizada para `versionName 0.12.3` e `versionCode 1203`.
- Capacitor permanece alinhado em 8.6.0; FFmpegKitNext permanece na versão configurada anteriormente (9.0.0).

## O que não muda
- Interface e recursos gráficos do RDV Bus.
- Exportação PNG estática e sequência PNG.
- Formatos de vídeo planejados: MOV QTRLE, MOV ProRes 4444, MOV PNG/RGBA, MKV FFV1/BGRA e WebM VP9 com alfa.
- Processamento incremental: os quadros são enviados e gravados individualmente em armazenamento temporário antes da codificação.
- Arquitetura Android Capacitor/Kotlin e Desktop Tauri/Rust.

## Estado dos testes
Esta entrega corrige o caminho de inicialização identificado por diagnóstico no CachyOS. O pacote-fonte foi submetido a verificações estáticas; não equivale a build validado no computador do usuário. A exportação Desktop precisa ser retestada com `npm run desktop:dev`, confirmando que `RDVNativeApp` e `RDVNativeVideo` ficam disponíveis e que os cinco codificadores são detectados. O Android não foi testado em dispositivo físico e continua pendente de compilação/validação.

## FFmpeg no Desktop
Em desenvolvimento, o backend Rust aceita FFmpeg encontrado no `PATH` (por exemplo `/usr/bin/ffmpeg`) ou `RDV_FFMPEG_PATH`. Builds de distribuição continuam exigindo binário compatível empacotado em `src-tauri/resources/ffmpeg/<plataforma>/`; não tornam FFmpeg do sistema uma dependência oculta do usuário final.
