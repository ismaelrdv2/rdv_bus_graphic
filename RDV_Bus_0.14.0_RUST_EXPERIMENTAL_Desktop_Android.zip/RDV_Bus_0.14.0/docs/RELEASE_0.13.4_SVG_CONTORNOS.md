# RDV Bus 0.13.4 — SVG para linhas e contornos

## Objetivo

Esta versão experimental ataca o defeito observado na 0.13.3: linhas e contornos continuavam serrilhados, enquanto os textos já apresentavam boa definição.

## Alterações

- Linhas registradas em camadas SVG passam a gerar o traço principal em SVG mesmo quando possuem brilho (`glow`).
- O brilho continua sendo desenhado pelo Canvas como camada de halo; o traço vetorial é composto por cima para recuperar a nitidez da borda.
- O redimensionamento das camadas de animação em supersampling para o canvas final passa a declarar `imageSmoothingEnabled` e `imageSmoothingQuality = high`.
- Mantido `ANIM_SS = 2` para não elevar indiscriminadamente o consumo de memória.
- Fotos, máscaras, texturas e efeitos rasterizados continuam no Canvas; o restante do pipeline resvg permanece.
- Versão Desktop/Tauri 0.13.4 e Android `versionName 0.13.4`, `versionCode 1304`.

## Limites conhecidos

A alteração vetorial foi aplicada à função compartilhada `line()`. Traços criados diretamente com `ctx.stroke()` fora dessa função ainda podem ser rasterizados; esta versão não pretende converter toda a aplicação para SVG.

## Teste recomendado

1. Gere o mesmo vídeo de referência usado para avaliar as versões 0.13.0 a 0.13.3.
2. Examine um quadro extraído do vídeo, não apenas a reprodução no player.
3. Compare linhas diagonais, contornos de painéis e elementos com brilho.
4. Compare também uma sequência PNG para confirmar que o caminho de exportação continua consistente.

Esta versão é experimental. A nitidez final precisa ser confirmada no ambiente de execução do usuário; o pacote não deve ser considerado visualmente validado antes desse teste.
