# RDV Bus 0.13.5 — retorno ao Canvas 2D + PNG

## Objetivo

Reverter integralmente as experiências SVG/resvg das versões 0.13.2, 0.13.3 e 0.13.4, retomando a arquitetura de renderização Canvas 2D da versão 0.11, preservada na base 0.13.0.

## Alterações

- `src/index.html` retorna ao desenho Canvas 2D direto para textos, linhas, polígonos, painéis e contornos.
- Removidos coletores SVG, composição SVG, rasterização resvg e a dependência WebAssembly.
- `localToOutput()` volta à composição direta via `drawImage()`, como na versão 0.11.
- Mantido `ANIM_SS = 2` e o cache de animações limitado a dois itens.
- Mantidos o pipeline de quadros PNG, a ponte nativa, o plugin Android e a codificação FFmpeg.
- Nenhuma redução de resolução foi aplicada.
- Android: `versionName 0.13.5`, `versionCode 1305`.

## Testes recomendados

1. Gerar o mesmo conteúdo de referência nas versões 0.11, 0.13.4 e 0.13.5.
2. Comparar PNG estático, sequência PNG e quadros extraídos dos vídeos.
3. Comparar os cinco formatos de vídeo suportados, com a mesma resolução, FPS e conteúdo.
4. Registrar RAM máxima durante a geração e duração total do processamento.
5. Confirmar funcionamento no Debian e CachyOS.

Esta versão é experimental. O pacote não deve ser considerado validado visualmente ou em consumo de RAM antes dos testes comparativos.

## Observação sobre lockfiles

O ZIP 0.13.4 recuperado não continha `package-lock.json` nem `src-tauri/Cargo.lock`. A tentativa de gerar o lockfile npm neste ambiente não pôde consultar o registro npm, e o executável Cargo não está disponível; por isso, nenhum lockfile foi inventado ou incluído. Antes de um build reprodutível, gere os lockfiles no ambiente de desenvolvimento com acesso aos registros e guarde-os junto ao código-fonte.
