# RDV Bus 0.12.1

## Ajustes desta versão

- Removido o botão de instalação/criação de atalho do WebApp.
- Removidos o diálogo de instalação PWA, o registro de Service Worker e os metadados de instalação PWA da interface nativa compartilhada.
- Mantidas as funções do editor, previews animadas, importação/exportação de ajustes e ponte nativa Android/Desktop existente.
- Alinhadas as versões do Capacitor CLI, Core e Android em 8.6.0.
- Atualizados os metadados de versão para 0.12.1 em package.json, Tauri, Rust, interface, diagnóstico e documentação.
- Incluído o ícone do Tauri a partir do ícone 512px já existente.

## Limitações mantidas

Esta atualização não implementa a ponte de exportação de vídeo do Desktop nem incorpora os binários FFmpeg ao pacote Desktop. A geração de vídeo Desktop continua pendente. O Android continua dependendo da preparação/compilação local do FFmpegKitNext conforme BUILD_ANDROID.md.

O projeto-fonte não equivale a APK/AAB, AppImage ou instalador EXE compilado e testado.
