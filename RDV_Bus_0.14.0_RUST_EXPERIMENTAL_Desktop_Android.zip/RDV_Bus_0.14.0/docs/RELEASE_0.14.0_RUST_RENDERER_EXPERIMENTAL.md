# RDV Bus 0.14.0 — Rust Renderer Experimental

Versão experimental isolada, baseada na 0.13.6. Não é uma versão candidata à publicação final.

## Opções de exportação de vídeo
- Renderização nativa: rasteriza diretamente na resolução final selecionada.
- Superamostragem: rasteriza em resolução ampliada e reduz no core Rust usando `image` (Lanczos3, Catmull-Rom ou Triangle).
- Saída: Full HD (1920×1080 / 1080×1920) ou 4K (3840×2160 / 2160×3840).
- Prioridade: qualidade máxima (2×; Lanczos3), equilibrada (1,5×; Catmull-Rom) ou desempenho/menor RAM (1,25×; Triangle).

O motor de composição ainda é o código JavaScript existente; nesta primeira etapa experimental, a rasterização de cada quadro ocorre em Canvas com escala física configurável e o core Rust faz a redução de superamostragem e codificação PNG intermediária. Portanto, esta versão testa o pipeline Rust de processamento de quadros e a rasterização ampliada, mas ainda não substitui todas as primitivas de desenho por Skia/Rust.

O caminho Rust é integrado ao Desktop/Tauri. Android e navegador usam fallback Canvas para a etapa de redução e não validam o core Rust nesta versão.

## Limites e observações
- 4K significa dimensões reais de saída, não apenas uma etiqueta de formato.
- A superamostragem aumenta memória e tempo; 4K + qualidade máxima pode exigir bastante RAM (raster interno até 7680×4320 em paisagem).
- A prioridade escolhe fator de ampliação e filtro de redução; não altera duração, FPS ou geometria da composição.
- A prévia continua em resolução padrão; as opções experimentais são aplicadas durante a exportação de vídeo.
- A dependência Rust `image` usa backend CPU e não requer GPU.

## Testes necessários
Comparar mesma composição em 1080p/4K, nativa/superamostragem e três prioridades. Registrar qualidade de diagonais, curvas e texto, RAM máxima e tempo total.
