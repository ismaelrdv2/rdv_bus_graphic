# RDV Bus 0.13.6 — pipeline de geração 0.11

## Objetivo
Restaurar integralmente, no caminho de geração de vídeo, o modelo de composição usado pela versão WebApp 0.11: Canvas de saída persistente, reutilizado quadro a quadro e passado como `target` a `RDV.animationFrame`.

## Mudanças
- Um Canvas RGBA com a resolução final é criado por exportação, não por quadro.
- `RDV.animationFrame(cfg,item,time,hold,canvas)` desenha no destino reutilizado, usando os canvases auxiliares/cacheados do renderizador quando aplicável.
- A imagem PNG é codificada a partir do Canvas persistente e enviada imediatamente ao FFmpeg.
- Compatível com os dois transportes da linha 0.13.x: API local Desktop/WebApp e plugin nativo Android.
- Mantém os encoders, os formatos, o empacotamento e o sistema de saída da linha 0.13.x.
- Limpa o Canvas e o cache de animação no `finally`, inclusive em falhas/cancelamentos.

## O que não foi alterado
- A renderização estática PNG e a sequência PNG.
- O desenho Canvas 2D dos elementos e os tempos/animações.
- A interface de formatos e o pipeline nativo de codificação.

## Validação
A alteração foi validada estaticamente. Este ambiente não dispõe das dependências instaladas nem de toolchain Cargo/Android para executar o build ou gerar vídeos de teste. A correção do serrilhamento e o consumo real de RAM precisam ser medidos no computador de destino.
