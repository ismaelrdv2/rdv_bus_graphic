# RDV Bus 0.13.2 — teste incremental SVG + Canvas

Esta versão experimental parte do código-fonte original 0.13.0.

## O que foi migrado nesta etapa

- Textos passam a ser construídos em uma camada SVG, preservando as coordenadas e medidas calculadas pelo Canvas.
- Linhas vetoriais simples desenhadas pela função compartilhada `line()` passam a ser construídas como caminhos SVG.
- O SVG incorpora a fonte DejaVu RDV embutida no próprio documento para reduzir diferenças tipográficas entre plataformas.
- A camada SVG é composta sobre o Canvas ao final da renderização estática.
- Fotografias, ícones rasterizados, texturas, máscaras, efeitos e demais composições continuam no Canvas.
- O renderizador Canvas original permanece como fallback no código (`SVG_VECTOR_TEST = false`).

## Limitações conhecidas desta etapa

- A migração ainda não cobre todos os caminhos internos de animação; o teste inicial concentra-se na renderização estática e nas prévias/exportações que usam `RDV.render()`.
- Alguns elementos vetoriais que ainda são desenhados diretamente por Canvas permanecem rasterizados.
- A camada SVG é composta no fim do quadro; sobreposições complexas entre texto e imagens precisam ser verificadas visualmente.
- Esta versão não deve ser considerada validada antes de comparação visual no Debian e CachyOS.

## Compilação

Como o pacote-base não inclui `package-lock.json` nem `src-tauri/Cargo.lock`, use `npm install` antes de `npm run build` na primeira preparação. Depois, compile o AppImage conforme `docs/BUILD_APPIMAGE_DEBIAN12.md`.
