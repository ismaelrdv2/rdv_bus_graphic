# RDV Bus 0.12.5 — FFmpeg opcional no Desktop

## Alterações
- O Desktop não incorpora mais o FFmpeg no AppImage nem no instalador Windows.
- O Tauri procura `RDV_FFMPEG_PATH` e, em seguida, `ffmpeg`/`ffmpeg.exe` no `PATH`, tanto em desenvolvimento quanto em Release.
- A ausência do FFmpeg não impede a inicialização nem a exportação de PNG e sequência PNG.
- Ao solicitar um formato de vídeo FFmpeg sem a dependência, a interface apresenta instruções de instalação para Linux ou Windows.
- A consulta de capacidades retorna estado estruturado quando o FFmpeg está ausente; erros de exportação passam a exibir uma mensagem legível em vez de `undefined`.
- Android permanece com FFmpegKitNext 9.0.0 e Capacitor 8.6.0; o script de preparação atualiza `versionName` para 0.12.5 e `versionCode` para 1205.
- Mantida a configuração explícita do ícone `icons/icon.png` para o AppImage.

## Formatos Desktop
Com FFmpeg instalado e os codificadores disponíveis: WebM VP9, MOV QTRLE, MOV ProRes 4444, MOV PNG/RGBA e MKV FFV1. Sequência PNG não depende de FFmpeg.

## Instalação do FFmpeg
- CachyOS/Arch Linux: `sudo pacman -S ffmpeg`
- Debian/Ubuntu: `sudo apt install ffmpeg`
- Windows: instalar uma distribuição FFmpeg e adicionar a pasta `bin` ao `PATH`; alternativamente, definir `RDV_FFMPEG_PATH` apontando para `ffmpeg.exe`.

Depois da instalação ou alteração do PATH, fechar e abrir novamente o RDV Bus.

## Estado da validação
Pacote-fonte submetido a verificações estáticas. Builds Tauri/AppImage/NSIS, execução sem FFmpeg e exportações de vídeo devem ser validados no ambiente de destino; a preparação Android e o teste em dispositivo também permanecem pendentes.
