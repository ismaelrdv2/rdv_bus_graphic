# Arquitetura nativa

```text
WebView / interface HTML
        |
        | Capacitor registerPlugin('RDVNativeVideo')
        v
RDVNativeVideoPlugin.kt
        |
        +-- addFrame(): recebe um PNG e grava imediatamente no cache privado
        |
        +-- finishVideoSession(): executa FFmpegKitNext sobre a sequência no disco
        |
        +-- exportVideo()/saveBlob(): publica no MediaStore
        |
        +-- createPackage()/finishPackage(): cria ZIP por streaming de arquivos
```

## Regras de memória

- O JavaScript gera um PNG por vez.
- O plugin nativo grava cada PNG em arquivo temporário privado.
- A sequência de quadros não é acumulada em uma lista JavaScript.
- O FFmpeg lê a sequência do disco; os encoders usam limite de threads para reduzir picos de memória.
- O plugin verifica espaço livre antes da sessão e a cada quadro, interrompendo a exportação antes de consumir todo o armazenamento temporário.
- O ZIP é montado por streaming com buffer de 128 KiB.
- A sessão temporária é removida após a exportação ou cancelamento; sobras de uma execução encerrada à força são limpas quando o plugin é carregado novamente.

## Formatos

| Chave da interface | Encoder | Contêiner | Pixel format |
|---|---|---|---|
| `qtrle` | qtrle | MOV | argb |
| `prores` | prores_ks (profile 4444) | MOV | yuva444p10le |
| `movpng` | png | MOV | rgba |
| `ffv1` | ffv1 level 3 | MKV | bgra |
| `vp9alpha` | libvpx-vp9 | WebM | yuva420p |

O suporte efetivo é detectado em runtime; se um encoder não estiver presente, a interface deve exibir o formato como indisponível.
