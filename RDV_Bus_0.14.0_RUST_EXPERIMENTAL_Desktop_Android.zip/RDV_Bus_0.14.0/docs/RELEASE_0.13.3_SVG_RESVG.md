# RDV Bus 0.13.3 — SVG + resvg no pipeline de animação

Versão experimental baseada no pacote 0.13.2. O objetivo desta etapa é garantir que os elementos vetoriais sejam rasterizados também nas camadas usadas pela animação, antes da composição dos quadros enviados ao FFmpeg.

## Alterações

- Adiciona `@resvg/resvg-wasm` 2.6.2, renderizador SVG baseado no projeto Rust resvg, executado localmente em WebAssembly.
- O módulo WASM é empacotado pelo Vite junto ao aplicativo: não há CDN, serviço remoto ou conexão de rede em tempo de execução.
- As camadas vetoriais criadas pelo motor `mkCanvas()` são coletadas e rasterizadas por resvg em RGBA.
- As camadas vetoriais das animações são rasterizadas assim que as camadas de animação são construídas e antes de serem compostas em cada quadro.
- A renderização estática e a animação compartilham o mesmo renderizador SVG.
- Canvas continua responsável por fotografias, ícones rasterizados, máscaras, texturas e efeitos.
- Mantém os formatos de exportação e o FFmpeg existentes.

## Limites e validação

Esta versão é experimental. O pipeline agora inclui resvg nas camadas vetoriais usadas pelas animações, mas ainda requer comparação visual e medição de desempenho no CachyOS e Debian. O comportamento de texto, ordem de sobreposição, transparência e uso de memória deve ser conferido em todos os tipos de animação.

O perfil de supersampling das camadas de animação permanece em `ANIM_SS = 2` para controlar o consumo de memória. O resvg usa renderização geométrica e tipográfica de alta qualidade (`shapeRendering: 2`, `textRendering: 2`).

## Dependência e licença

`@resvg/resvg-wasm` 2.6.2 — MPL-2.0. O arquivo WASM é parte do bundle local do aplicativo. Consulte `THIRD_PARTY_NOTICES.md`.

## Preparação e compilação

O pacote-fonte não inclui `node_modules`. Execute `npm install` na primeira preparação e, em seguida, `npm run desktop:build -- --bundles appimage`. O Vite copiará o WASM para os assets da aplicação.
