#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 não foi encontrado. Instale Python 3 para iniciar o servidor local."
  read -r _
  exit 1
fi
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "AVISO: FFmpeg não foi encontrado no PATH."
  echo "Para habilitar WebM VP9 com alfa e MOV (QTRLE/ProRes 4444), instale-o:"
  echo "  CachyOS / Arch: sudo pacman -S ffmpeg"
  echo "  Ubuntu / Debian: sudo apt install ffmpeg"
  echo "O aplicativo ainda poderá gerar PNG e WebM pela captura do navegador."
  echo
fi
exec python3 servidor_local.py
