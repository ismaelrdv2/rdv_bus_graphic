@echo off
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3 nao foi encontrado. Instale Python 3.
  pause
  exit /b 1
)
where ffmpeg >nul 2>nul
if errorlevel 1 echo AVISO: FFmpeg nao foi encontrado no PATH. MOV/VP9 com alfa ficarao indisponiveis ate instalar FFmpeg.
python servidor_local.py
pause
