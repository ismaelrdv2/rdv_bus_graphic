#!/usr/bin/env python3
"""Servidor local do RDV Bus WebApp 0.11.
Serve o editor e oferece codificação FFmpeg local para MOV, MKV e WebM com canal alfa.
Não faz hospedagem externa nem envia dados para a internet.
"""
from __future__ import annotations
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse, quote
from threading import RLock, Timer
import argparse, json, os, secrets, shutil, socket, subprocess, tempfile, time, zipfile

BASE = Path(__file__).resolve().parent
MAX_BODY = 32 * 1024 * 1024
MAX_FRAMES = 7200
MAX_PIXELS = 3840 * 2160
SESSION_TTL = 6 * 60 * 60
TEMP_BASE = Path(tempfile.gettempdir()) / 'rdv_bus_webapp_0_11'
TEMP_BASE.mkdir(parents=True, exist_ok=True)
SESSIONS: dict[str, dict] = {}
LOCK = RLock()

FORMATOS = {
    'movpng': {
        'ext': '.mov', 'mime': 'video/quicktime', 'codec': 'QuickTime PNG (RGBA sem perdas)',
        'encoder': 'png', 'args': ['-c:v', 'png', '-pix_fmt', 'rgba', '-threads', '2']
    },
    'ffv1': {
        'ext': '.mkv', 'mime': 'video/x-matroska', 'codec': 'FFV1 (BGRA sem perdas)',
        'encoder': 'ffv1', 'args': ['-c:v', 'ffv1', '-level', '3', '-pix_fmt', 'bgra', '-threads', '2']
    },
    'vp9alpha': {
        'ext': '.webm', 'mime': 'video/webm', 'codec': 'VP9 com canal alfa',
        'encoder': 'libvpx-vp9',
        'args': ['-c:v', 'libvpx-vp9', '-pix_fmt', 'yuva420p', '-auto-alt-ref', '0',
                 '-b:v', '0', '-crf', '26', '-deadline', 'good', '-cpu-used', '5',
                 '-row-mt', '1', '-threads', '2']
    },
    'qtrle': {
        'ext': '.mov', 'mime': 'video/quicktime', 'codec': 'QuickTime Animation (QTRLE)',
        'encoder': 'qtrle', 'args': ['-c:v', 'qtrle', '-pix_fmt', 'argb', '-threads', '2']
    },
    'prores': {
        'ext': '.mov', 'mime': 'video/quicktime', 'codec': 'Apple ProRes 4444',
        'encoder': 'prores_ks',
        'args': ['-c:v', 'prores_ks', '-profile:v', '4444', '-vendor', 'apl0',
                 '-alpha_bits', '16', '-pix_fmt', 'yuva444p10le', '-threads', '2']
    }
}


def locate_ffmpeg() -> str | None:
    candidates = [shutil.which('ffmpeg')]
    for key in ('ProgramFiles', 'ProgramFiles(x86)', 'LOCALAPPDATA'):
        root = os.environ.get(key)
        if root:
            candidates.extend([
                os.path.join(root, 'kdenlive', 'bin', 'ffmpeg.exe'),
                os.path.join(root, 'Kdenlive', 'bin', 'ffmpeg.exe'),
            ])
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return str(candidate)
    return None

FFMPEG = locate_ffmpeg()
ENCODERS: set[str] = set()
FFMPEG_VERSION = ''
if FFMPEG:
    try:
        v = subprocess.run([FFMPEG, '-version'], capture_output=True, text=True, timeout=10)
        FFMPEG_VERSION = (v.stdout.splitlines() or ['FFmpeg'])[0]
        e = subprocess.run([FFMPEG, '-hide_banner', '-encoders'], capture_output=True, text=True, timeout=20)
        ENCODERS = {name for name in ('libvpx-vp9', 'qtrle', 'prores_ks', 'png', 'ffv1') if name in (e.stdout + e.stderr)}
    except Exception:
        FFMPEG = None
        ENCODERS = set()


def json_bytes(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False).encode('utf-8')


def safe_filename(name: str, fallback='video') -> str:
    name = Path(str(name or fallback)).name
    name = ''.join(c for c in name if c not in '<>:/\\|?*\0' and ord(c) >= 32).strip(' .')
    return (name or fallback)[:150]


def safe_relpath(name: str) -> str:
    p = PurePosixPath(str(name or ''))
    if p.is_absolute() or not p.parts or any(part in ('', '.', '..') for part in p.parts):
        raise ValueError('Caminho de arquivo inválido.')
    if any('\\' in part or ':' in part for part in p.parts):
        raise ValueError('Caminho de arquivo inválido.')
    return str(p)


def cleanup_session(token: str):
    with LOCK:
        entry = SESSIONS.pop(token, None)
    if entry:
        shutil.rmtree(entry['root'], ignore_errors=True)


def cleanup_stale():
    cutoff = time.time() - SESSION_TTL
    with LOCK:
        stale = [token for token, item in SESSIONS.items() if item.get('created', 0) < cutoff]
    for token in stale:
        cleanup_session(token)


class Handler(SimpleHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE), **kwargs)

    def log_message(self, fmt, *args):
        pass

    def send_json(self, status: int, data):
        body = json_bytes(data)
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get('Content-Length', '0'))
        if length <= 0 or length > 1024 * 1024:
            raise ValueError('Corpo da requisição ausente ou muito grande.')
        return json.loads(self.rfile.read(length).decode('utf-8'))

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/capabilities':
            formats = {key: (FORMATOS[key]['encoder'] in ENCODERS) for key in FORMATOS}
            self.send_json(200, {
                'ok': True, 'ffmpeg': bool(FFMPEG), 'ffmpegVersion': FFMPEG_VERSION,
                'formats': formats,
                'message': 'Codificação local disponível.' if FFMPEG else 'FFmpeg não encontrado. Instale-o para habilitar MOV, MKV FFV1 e WebM VP9 com alfa.'
            })
            return
        if path.startswith('/api/video/download/'):
            self.download_output(path.rsplit('/', 1)[-1])
            return
        super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path.rstrip('/')
        try:
            if path == '/api/video/session':
                self.create_session(); return
            if path == '/api/video/package':
                self.create_package(); return
            parts = path.split('/')
            if len(parts) == 6 and parts[1:3] == ['api', 'video'] and parts[3] == 'session' and parts[5] == 'finish':
                self.finish_session(parts[4]); return
            if len(parts) == 7 and parts[1:3] == ['api', 'video'] and parts[3] == 'session' and parts[5] == 'frame':
                self.receive_frame(parts[4], parts[6]); return
            if len(parts) == 6 and parts[1:3] == ['api', 'video'] and parts[3] == 'session' and parts[5] == 'cancel':
                cleanup_session(parts[4]); self.send_json(200, {'ok': True}); return
            self.send_json(404, {'error': 'Endpointo não encontrado.'})
        except ValueError as exc:
            self.send_json(400, {'error': str(exc)})
        except KeyError as exc:
            self.send_json(404, {'error': str(exc) or 'Sessão não encontrada.'})
        except Exception as exc:
            self.send_json(500, {'error': f'Falha no servidor local: {exc}'})

    def create_session(self):
        if not FFMPEG:
            self.send_json(503, {'error': 'FFmpeg não foi encontrado. Instale FFmpeg e reinicie iniciar_servidor.sh.'}); return
        data = self.read_json()
        fmt = str(data.get('format', ''))
        if fmt not in FORMATOS:
            raise ValueError('Formato de vídeo não reconhecido.')
        if FORMATOS[fmt]['encoder'] not in ENCODERS:
            self.send_json(503, {'error': f'O FFmpeg instalado não possui o codificador {FORMATOS[fmt]["encoder"]}.'}); return
        width, height = int(data.get('width', 0)), int(data.get('height', 0))
        fps, frames = int(data.get('fps', 0)), int(data.get('frames', 0))
        if width < 16 or height < 16 or width > 3840 or height > 3840 or width * height > MAX_PIXELS:
            raise ValueError('Resolução fora dos limites permitidos.')
        if fps not in (24, 25, 30, 50, 60): raise ValueError('FPS inválido.')
        if frames < 1 or frames > MAX_FRAMES: raise ValueError(f'Quantidade de quadros inválida (máximo {MAX_FRAMES}).')
        cleanup_stale()
        token = secrets.token_urlsafe(24)
        root = Path(tempfile.mkdtemp(prefix='sess_', dir=TEMP_BASE))
        frame_dir = root / 'frames'; frame_dir.mkdir()
        entry = {'kind': 'video', 'root': root, 'frames_dir': frame_dir, 'width': width,
                 'height': height, 'fps': fps, 'frames': frames, 'format': fmt,
                 'received': 0, 'created': time.time(), 'ready': False,
                 'requested_name': safe_filename(data.get('filename', 'rdv_export' + FORMATOS[fmt]['ext']))}
        with LOCK: SESSIONS[token] = entry
        self.send_json(201, {'ok': True, 'token': token, 'frames': frames, 'fps': fps})

    def find_session(self, token):
        with LOCK: entry = SESSIONS.get(token)
        if not entry: raise KeyError('Sessão de exportação não encontrada ou já encerrada.')
        return entry

    def receive_frame(self, token: str, index_text: str):
        entry = self.find_session(token)
        try: index = int(index_text)
        except ValueError: raise ValueError('Índice de quadro inválido.')
        length = int(self.headers.get('Content-Length', '0'))
        if length < 32 or length > MAX_BODY: raise ValueError('Quadro PNG ausente ou excede 32 MB.')
        if entry['ready']: raise ValueError('A sessão já foi codificada.')
        if index != entry['received']: raise ValueError(f'Ordem de quadros inválida: esperado {entry["received"]}, recebido {index}.')
        data = self.rfile.read(length)
        if len(data) != length or not data.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError('O quadro recebido não é um PNG válido.')
        w = int.from_bytes(data[16:20], 'big'); h = int.from_bytes(data[20:24], 'big')
        if (w, h) != (entry['width'], entry['height']): raise ValueError('Dimensões do quadro não correspondem à sessão.')
        target = entry['frames_dir'] / f'frame_{index:06d}.png'
        target.write_bytes(data)
        entry['received'] += 1; entry['created'] = time.time()
        self.send_json(201, {'ok': True, 'received': entry['received'], 'total': entry['frames']})

    def finish_session(self, token: str):
        entry = self.find_session(token)
        if entry['received'] != entry['frames']:
            raise ValueError(f'Faltam quadros: recebidos {entry["received"]} de {entry["frames"]}.')
        fmt = FORMATOS[entry['format']]
        output_name = entry.get('requested_name') or ('rdv_export' + fmt['ext'])
        if not output_name.lower().endswith(fmt['ext']): output_name += fmt['ext']
        output_path = entry['root'] / output_name
        frame_pattern = str(entry['frames_dir'] / 'frame_%06d.png')
        cmd = [FFMPEG, '-hide_banner', '-loglevel', 'error', '-y',
               '-threads', '1', '-framerate', str(entry['fps']), '-start_number', '0',
               '-i', frame_pattern, '-frames:v', str(entry['frames']), '-an']
        cmd += fmt['args']
        if fmt['ext'] == '.mov': cmd += ['-movflags', '+faststart']
        cmd += ['-metadata', 'title=RDV Bus WebApp', str(output_path)]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        except subprocess.TimeoutExpired:
            raise RuntimeError('O FFmpeg ultrapassou o limite de 15 minutos. Tente 30 FPS ou um vídeo mais curto.')
        if result.returncode != 0 or not output_path.exists() or output_path.stat().st_size < 128:
            detail = (result.stderr or 'O FFmpeg não criou o arquivo de saída.')[-2500:]
            raise RuntimeError(f'FFmpeg não conseguiu criar {fmt["ext"]}: {detail}')
        shutil.rmtree(entry['frames_dir'], ignore_errors=True)
        entry['frames_dir'] = None
        entry['output'] = output_path; entry['filename'] = output_name; entry['mime'] = fmt['mime']
        entry['size'] = output_path.stat().st_size; entry['codec'] = fmt['codec']; entry['ready'] = True
        entry['created'] = time.time()
        self.send_json(200, {'ok': True, 'token': token, 'filename': output_name,
                             'size': entry['size'], 'codec': entry['codec'],
                             'url': f'/api/video/download/{token}'})

    def create_package(self):
        data = self.read_json()
        files = data.get('files')
        if not isinstance(files, list) or not files or len(files) > 200:
            raise ValueError('Lista de vídeos para o ZIP inválida.')
        token = secrets.token_urlsafe(24)
        root = Path(tempfile.mkdtemp(prefix='zip_', dir=TEMP_BASE))
        package = root / safe_filename(data.get('filename', 'RDV_Bus_videos.zip'), 'RDV_Bus_videos.zip')
        sources = []
        try:
            with zipfile.ZipFile(package, 'w', compression=zipfile.ZIP_STORED, allowZip64=True) as zf:
                for item in files:
                    source_token = str(item.get('token', ''))
                    entry = self.find_session(source_token)
                    if entry['kind'] != 'video' or not entry.get('ready') or not entry.get('output'):
                        raise ValueError('Um dos vídeos ainda não foi codificado.')
                    arcname = safe_relpath(item.get('name', entry['filename']))
                    zf.write(entry['output'], arcname)
                    sources.append(source_token)
        except Exception:
            shutil.rmtree(root, ignore_errors=True)
            raise
        with LOCK:
            SESSIONS[token] = {'kind': 'package', 'root': root, 'output': package,
                               'filename': package.name, 'mime': 'application/zip',
                               'size': package.stat().st_size, 'ready': True,
                               'sources': sources, 'created': time.time()}
        self.send_json(201, {'ok': True, 'token': token, 'filename': package.name,
                             'size': package.stat().st_size, 'url': f'/api/video/download/{token}'})

    def download_output(self, token: str):
        try: entry = self.find_session(token)
        except KeyError:
            self.send_error(404, 'Arquivo de exportação não encontrado ou download já concluído.'); return
        path = entry.get('output')
        if not entry.get('ready') or not path or not Path(path).is_file():
            self.send_error(404, 'Arquivo ainda não está pronto.'); return
        size = Path(path).stat().st_size
        filename = safe_filename(entry.get('filename', 'rdv_output'))
        self.send_response(200)
        self.send_header('Content-Type', entry.get('mime', 'application/octet-stream'))
        self.send_header('Content-Length', str(size))
        self.send_header('Content-Disposition', f"attachment; filename=\"{filename}\"; filename*=UTF-8''{quote(filename)}")
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        try:
            with Path(path).open('rb') as f:
                shutil.copyfileobj(f, self.wfile, length=1024 * 1024)
            if entry['kind'] == 'package':
                for source in entry.get('sources', []): cleanup_session(source)
            cleanup_session(token)
        except (BrokenPipeError, ConnectionResetError):
            # Mantém o arquivo para que o usuário possa tentar baixar novamente.
            pass


def ips_locais():
    found = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith('127.'): found.add(ip)
    except OSError: pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(('192.0.2.1', 80))
        ip = s.getsockname()[0]; s.close()
        if not ip.startswith('127.'): found.add(ip)
    except OSError: pass
    return sorted(found)


def main():
    parser = argparse.ArgumentParser(description='Servidor local do RDV Bus WebApp 0.11')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--host', default='0.0.0.0')
    parser.add_argument('--no-open', action='store_true', help='Não abrir o navegador automaticamente')
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.daemon_threads = True
    local_url = f'http://127.0.0.1:{args.port}/'
    print('RDV Bus WebApp 0.11 — ALFA / Open Source')
    print(f'Este computador: {local_url}')
    for ip in ips_locais(): print(f'Na rede local: http://{ip}:{args.port}/')
    if FFMPEG:
        print(f'FFmpeg encontrado: {FFMPEG_VERSION}')
        available = [key for key, spec in FORMATOS.items() if spec['encoder'] in ENCODERS]
        print('Formatos com transparência: ' + (', '.join(available) if available else 'nenhum codificador compatível'))
    else:
        print('AVISO: FFmpeg não encontrado. PNG continuará funcionando; instale FFmpeg para habilitar MOV/MKV e WebM VP9 com alfa.')
        print('CachyOS/Arch: sudo pacman -S ffmpeg')
        print('Ubuntu/Debian: sudo apt install ffmpeg')
    print('O servidor fica somente na rede local. Mantenha esta janela aberta durante a utilização. Ctrl+C encerra.')
    if not args.no_open:
        Timer(0.8, lambda: __import__('webbrowser').open(local_url)).start()
    try: server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt: print('\nServidor encerrado.')
    finally:
        server.server_close()
        with LOCK: tokens = list(SESSIONS)
        for token in tokens: cleanup_session(token)

if __name__ == '__main__': main()
