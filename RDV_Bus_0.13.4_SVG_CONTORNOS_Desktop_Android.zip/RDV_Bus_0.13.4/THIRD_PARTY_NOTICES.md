# Avisos de componentes de terceiros

Este arquivo identifica dependências previstas. A lista final deve ser regenerada após a compilação efetiva do FFmpegKitNext, de acordo com os componentes presentes no AAR e nas bibliotecas nativas.

- Capacitor: MIT — https://github.com/ionic-team/capacitor
- Vite: MIT — https://github.com/vitejs/vite
- FFmpegKitNext: LGPL 3.0 por padrão; GPL v3 somente se opções/bibliotecas GPL forem habilitadas — https://github.com/arthenica/ffmpeg-kit-next
- FFmpeg: LGPL/GPL conforme configuração compilada — https://ffmpeg.org/legal.html
- libvpx: BSD 3-Clause — https://github.com/webmproject/libvpx

O script de compilação habilita `libvpx` para o encoder VP9 e não habilita `--enable-gpl`. Verifique a saída de configuração, as licenças de todos os componentes e as obrigações de patentes antes de distribuir binários.

- resvg / @resvg/resvg-wasm 2.6.2: MPL-2.0 — https://github.com/thx/resvg-js — renderização SVG local via WebAssembly.
