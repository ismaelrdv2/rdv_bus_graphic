#!/usr/bin/env python3
"""Apply RDV Bus native Android plugin and Gradle wiring after `cap add android`."""
from pathlib import Path
import re
import shutil
import sys

root = Path(__file__).resolve().parents[1]
android = root / 'android'
if not (android / 'app' / 'build.gradle').exists():
    raise SystemExit('Android não encontrado. Execute primeiro: npx cap add android')

# Place the custom Kotlin plugin and Java activity in the package Capacitor uses.
java_dir = android / 'app/src/main/java/com/rdvsoftware/rdvbus'
java_dir.mkdir(parents=True, exist_ok=True)
shutil.copy2(root / 'native/android/RDVNativeVideoPlugin.kt', java_dir / 'RDVNativeVideoPlugin.kt')
shutil.copy2(root / 'android-template/app/src/main/java/com/rdvsoftware/rdvbus/MainActivity.java', java_dir / 'MainActivity.java')

# Install the RDV launcher icons and application label into Android resources.
source_res = root / 'android-template/app/src/main/res'
target_res = android / 'app/src/main/res'
if source_res.exists():
    shutil.copytree(source_res, target_res, dirs_exist_ok=True)

# Add Kotlin Gradle plugin to the root buildscript. Capacitor 8 uses AGP 8.13.x;
# Kotlin 2.3.0 is the compatible KGP line for AGP 8.13.0.
root_gradle = android / 'build.gradle'
s = root_gradle.read_text()
if 'kotlin-gradle-plugin' not in s:
    m = re.search(r'dependencies\s*\{', s)
    if not m:
        raise SystemExit('Não localizei dependencies { em android/build.gradle')
    pos = m.end()
    s = s[:pos] + "\n        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:2.3.0'\n" + s[pos:]

settings = android / 'settings.gradle'
central_repos = False
if settings.exists():
    settings_text = settings.read_text()
    central_repos = 'dependencyResolutionManagement' in settings_text and 'repositoriesMode' in settings_text
    if central_repos and 'ffmpegkit-maven' not in settings_text:
        m = re.search(r'dependencyResolutionManagement\s*\{[\s\S]*?repositories\s*\{', settings_text)
        if not m:
            raise SystemExit('Não localizei repositories dentro de dependencyResolutionManagement.')
        pos = m.end()
        settings_text = settings_text[:pos] + '\n        maven { url = uri("$rootDir/ffmpegkit-maven") }\n' + settings_text[pos:]
        settings.write_text(settings_text)

if not central_repos and 'ffmpegkit-maven' not in s:
    # Standard Capacitor template declares allprojects.repositories in the root file.
    m = re.search(r'allprojects\s*\{\s*repositories\s*\{', s)
    if m:
        pos = m.end()
        s = s[:pos] + '\n        maven { url "$rootDir/ffmpegkit-maven" }\n' + s[pos:]
    else:
        s += '\nallprojects { repositories { maven { url "$rootDir/ffmpegkit-maven" } } }\n'
root_gradle.write_text(s)

app_gradle = android / 'app/build.gradle'
s = app_gradle.read_text()
if "org.jetbrains.kotlin.android" not in s:
    # Keep the Android application plugin first, then enable Kotlin for the bridge.
    s = re.sub(r"(apply plugin:\s*['\"]com\.android\.application['\"]\s*)",
               r"\1\napply plugin: 'org.jetbrains.kotlin.android'\n", s, count=1)
if 'com.arthenica:ffmpeg-kit-next:9.0.0' not in s:
    m = re.search(r'dependencies\s*\{', s)
    if not m:
        s += "\ndependencies { implementation 'com.arthenica:ffmpeg-kit-next:9.0.0' }\n"
    else:
        pos = m.end()
        s = s[:pos] + "\n    implementation 'com.arthenica:ffmpeg-kit-next:9.0.0'" + s[pos:]
s = re.sub(r'namespace\s*[= ]\s*[\"\'][^\"\']+[\"\']', 'namespace = "com.rdvsoftware.rdvbus"', s, count=1)
s = re.sub(r'applicationId\s+[\"\'][^\"\']+[\"\']', 'applicationId "com.rdvsoftware.rdvbus"', s, count=1)
# Keep the Android package version aligned with the shared RDV Bus release.
# versionCode 1304 maps to release 0.13.4; increment it for every future Android release.
s, _ = re.subn(r'versionCode\s+\d+', 'versionCode 1304', s, count=1)
s, n_version = re.subn(r'versionName\s+[\"\'][^\"\']*[\"\']', 'versionName \"0.13.4\"', s, count=1)
if n_version == 0:
    s = re.sub(r'(defaultConfig\s*\{)', r'\1\n        versionCode 1304\n        versionName \"0.13.4\"', s, count=1)
app_gradle.write_text(s)

# Capacitor 8's variables file is the source of SDK levels.
variables = android / 'variables.gradle'
if variables.exists():
    s = variables.read_text()
    for key, value in [('minSdkVersion', '29'), ('compileSdkVersion', '36'), ('targetSdkVersion', '36')]:
        pattern = rf'({key}\s*=\s*)\d+'
        s, n = re.subn(pattern, rf'\g<1>{value}', s, count=1)
        if n == 0:
            s = re.sub(r'ext\s*\{', lambda m: m.group(0) + f'\n    {key} = {value}', s, count=1)
    variables.write_text(s)

print('Integração Android aplicada: plugin Kotlin, MainActivity, Maven local e SDK 29/36.')
