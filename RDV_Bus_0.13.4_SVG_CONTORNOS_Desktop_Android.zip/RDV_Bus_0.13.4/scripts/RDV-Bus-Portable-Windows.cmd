@echo off
setlocal
rem Iniciador do pacote portátil. Mantém RDV-Bus.exe na mesma pasta.
set "APP=%~dp0RDV-Bus.exe"
if not exist "%APP%" (
  powershell -NoProfile -Command "$roots=@('HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients','HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients','HKCU:\Software\Microsoft\EdgeUpdate\Clients'); $found=$false; foreach($root in $roots){ if(Test-Path $root){ foreach($key in (Get-ChildItem $root -ErrorAction SilentlyContinue)){ $p=Get-ItemProperty $key.PSPath -ErrorAction SilentlyContinue; if($p.name -match 'WebView2 Runtime' -and $p.pv){$found=$true} } } }; if(-not $found){Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('O Microsoft Edge WebView2 Runtime não foi detectado. Instale o WebView2 Runtime e abra o RDV Bus novamente.','RDV Bus 0.13.4 - dependência ausente','OK','Warning') | Out-Null; exit 1}"
if errorlevel 1 exit /b 1
start "" "%APP%"
