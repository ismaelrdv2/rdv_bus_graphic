use base64::{engine::general_purpose::STANDARD as B64, Engine};
use serde::Serialize;
use serde_json::json;
use std::{collections::HashMap, fs::{self, File}, io::{Read, Write}, path::{Path, PathBuf}, process::Command, sync::Mutex};
use tauri::{Manager, State};
use tauri_plugin_dialog::DialogExt;
use uuid::Uuid;
use zip::{write::SimpleFileOptions, ZipWriter};

#[derive(Default)]
struct DesktopState { videos: Mutex<HashMap<String, VideoJob>>, packages: Mutex<HashMap<String, PackageJob>> }
struct VideoJob { root: PathBuf, frames: PathBuf, output: PathBuf, width: u32, height: u32, fps: u32, expected: u32, received: u32, format: String, filename: String, ready: bool }
struct PackageJob { root: PathBuf, filename: String, items: Vec<(String, PathBuf)> }

#[derive(Serialize)] struct RuntimeReport { platform: String, app_version: String, webview: Check, ffmpeg: Check, encoders: EncoderChecks, warnings: Vec<String> }
#[derive(Serialize)] struct Check { available: bool, detail: String }
#[derive(Serialize, Clone)] struct EncoderChecks { qtrle: bool, prores: bool, movpng: bool, ffv1: bool, vp9alpha: bool }

fn ffmpeg_path(_app: &tauri::AppHandle) -> Option<PathBuf> {
    let name = if cfg!(windows) { "ffmpeg.exe" } else { "ffmpeg" };

    // Caminho personalizado tem prioridade sobre o PATH do sistema.
    if let Some(path) = std::env::var_os("RDV_FFMPEG_PATH") {
        let path = PathBuf::from(path);
        if Command::new(&path)
            .arg("-version")
            .output()
            .is_ok_and(|output| output.status.success())
        {
            return Some(path);
        }
    }

    // Funciona em debug e release: Command resolve o executável pelo PATH.
    let system = PathBuf::from(name);
    if Command::new(&system)
        .arg("-version")
        .output()
        .is_ok_and(|output| output.status.success())
    {
        return Some(system);
    }

    None
}
fn encoder_available(list: &str, encoder: &str) -> bool { list.lines().any(|l| { let mut f=l.split_whitespace(); f.next(); f.next()==Some(encoder) }) }
fn caps(app: &tauri::AppHandle) -> Result<(PathBuf, EncoderChecks, String), String> {
    let bin = ffmpeg_path(app).ok_or_else(|| {
        if cfg!(windows) {
            "FFmpeg não encontrado. Instale o FFmpeg e adicione a pasta bin ao PATH do Windows. Depois, feche e abra novamente o RDV Bus.".to_string()
        } else {
            "FFmpeg não encontrado. Instale-o pelo gerenciador de pacotes da sua distribuição. CachyOS/Arch Linux: sudo pacman -S ffmpeg. Debian/Ubuntu: sudo apt install ffmpeg. Depois, feche e abra novamente o RDV Bus.".to_string()
        }
    })?;
    let out=Command::new(&bin).args(["-hide_banner","-encoders"]).output().map_err(|e| format!("Não foi possível executar FFmpeg: {e}"))?;
    if !out.status.success() { return Err("FFmpeg retornou erro ao consultar os codificadores.".into()); }
    let text=String::from_utf8_lossy(&out.stdout).to_string();
    let c=EncoderChecks { qtrle:encoder_available(&text,"qtrle"), prores:encoder_available(&text,"prores_ks"), movpng:encoder_available(&text,"png"), ffv1:encoder_available(&text,"ffv1"), vp9alpha:encoder_available(&text,"libvpx-vp9") };
    let ver=Command::new(&bin).arg("-version").output().ok().map(|o|String::from_utf8_lossy(&o.stdout).lines().next().unwrap_or("FFmpeg").to_string()).unwrap_or_else(||"FFmpeg".into());
    Ok((bin,c,ver))
}
fn format_args(fmt:&str)->Result<Vec<&'static str>,String>{ Ok(match fmt {
 "qtrle"=>vec!["-c:v","qtrle","-pix_fmt","argb","-threads","2"],
 "prores"=>vec!["-c:v","prores_ks","-profile:v","4444","-vendor","apl0","-alpha_bits","16","-pix_fmt","yuva444p10le","-threads","2"],
 "movpng"=>vec!["-c:v","png","-pix_fmt","rgba","-threads","2"],
 "ffv1"=>vec!["-c:v","ffv1","-level","3","-pix_fmt","bgra","-threads","2"],
 "vp9alpha"=>vec!["-c:v","libvpx-vp9","-pix_fmt","yuva420p","-auto-alt-ref","0","-b:v","0","-crf","26","-deadline","good","-cpu-used","5","-row-mt","1","-threads","2"],
 _=>return Err(format!("Formato não suportado: {fmt}")) }) }
fn ext(fmt:&str)->&'static str { match fmt {"qtrle"|"prores"|"movpng"=>".mov","ffv1"=>".mkv","vp9alpha"=>".webm",_=>".bin"} }
fn safe_name(s:&str)->String { let s=s.rsplit(|c| c == '/' || c == '\\').next().unwrap_or("rdv_export"); let out:String=s.chars().map(|c|if c.is_ascii_alphanumeric()||"._-".contains(c){c}else{'_'}).collect(); let out=out.trim_matches(|c| c == '.' || c == '_'); if out.is_empty(){"rdv_export".into()}else{out.chars().take(140).collect()} }
fn safe_rel(s:&str)->String { s.split(|c| c == '/' || c == '\\').filter(|p|!p.is_empty()&&*p!="."&&*p!="..").map(safe_name).collect::<Vec<_>>().join("/") }
fn app_temp(app:&tauri::AppHandle, kind:&str, token:&str)->Result<PathBuf,String>{ let p=app.path().app_cache_dir().map_err(|e|e.to_string())?.join("rdv-native").join(kind).join(token); fs::create_dir_all(&p).map_err(|e|format!("Não foi possível criar temporários: {e}"))?; Ok(p) }

#[tauri::command] fn diagnose_runtime(app:tauri::AppHandle)->RuntimeReport {
 let result=caps(&app); let (ff,enc,warnings)=match result { Ok((p,c,_))=>{let mut w=Vec::new(); for (n,v) in [("MOV QTRLE",c.qtrle),("MOV ProRes 4444",c.prores),("MOV PNG/RGBA",c.movpng),("MKV FFV1",c.ffv1),("WebM VP9 com alfa",c.vp9alpha)] {if !v{w.push(format!("Codificador ausente: {n}."));}} (Check{available:true,detail:format!("FFmpeg disponível: {}",p.display())},c,w)}, Err(e)=>(Check{available:false,detail:e.clone()},EncoderChecks{qtrle:false,prores:false,movpng:false,ffv1:false,vp9alpha:false},vec![e])};
 RuntimeReport{platform:std::env::consts::OS.into(),app_version:app.package_info().version.to_string(),webview:Check{available:true,detail:"WebView iniciado com sucesso.".into()},ffmpeg:ff,encoders:enc,warnings}
}
#[tauri::command]
fn desktop_get_capabilities(app: tauri::AppHandle) -> Result<serde_json::Value, String> {
    match caps(&app) {
        Ok((_, c, version)) => Ok(json!({
            "ok": true,
            "ffmpeg": true,
            "ffmpegVersion": version,
            "formats": {
                "qtrle": c.qtrle,
                "prores": c.prores,
                "movpng": c.movpng,
                "ffv1": c.ffv1,
                "vp9alpha": c.vp9alpha
            }
        })),
        Err(error) => Ok(json!({
            "ok": true,
            "ffmpeg": false,
            "ffmpegVersion": null,
            "error": error,
            "formats": {
                "qtrle": false,
                "prores": false,
                "movpng": false,
                "ffv1": false,
                "vp9alpha": false
            }
        }))
    }
}
#[tauri::command] fn desktop_create_video_session(app:tauri::AppHandle,state:State<'_,DesktopState>,format:String,width:u32,height:u32,fps:u32,frames:u32,filename:Option<String>)->Result<serde_json::Value,String>{
 let (_,c,_)=caps(&app)?; let supported=match format.as_str(){"qtrle"=>c.qtrle,"prores"=>c.prores,"movpng"=>c.movpng,"ffv1"=>c.ffv1,"vp9alpha"=>c.vp9alpha,_=>false}; if !supported{return Err(format!("O codificador {format} não está disponível nesta compilação."));}
 if !(16..=3840).contains(&width)||!(16..=3840).contains(&height)||width as u64*height as u64>3840*2160||![24,25,30,50,60].contains(&fps)||frames==0||frames>7200{return Err("Resolução, FPS ou quantidade de quadros inválida.".into());}
 let token=Uuid::new_v4().simple().to_string();let root=app_temp(&app,"video",&token)?;let fd=root.join("frames");fs::create_dir_all(&fd).map_err(|e|e.to_string())?;let filename=safe_name(filename.as_deref().unwrap_or(&format!("rdv_export{}",ext(&format))));
 state.videos.lock().map_err(|e|e.to_string())?.insert(token.clone(),VideoJob{root:root.clone(),frames:fd,output:root.join(&filename),width,height,fps,expected:frames,received:0,format,filename,ready:false}); Ok(json!({"ok":true,"token":token,"frames":frames,"fps":fps})) }
#[tauri::command] fn desktop_add_frame(state:State<'_,DesktopState>,token:String,index:u32,data:String)->Result<serde_json::Value,String>{
 let mut map=state.videos.lock().map_err(|e|e.to_string())?;let j=map.get_mut(&token).ok_or("Sessão de vídeo não encontrada.")?;if j.ready||index!=j.received{return Err(format!("Quadro fora de ordem; esperado {}.",j.received));}let bytes=B64.decode(data.split(',').last().unwrap_or(&data)).map_err(|e|e.to_string())?;if bytes.len()<32||bytes.len()>24*1024*1024||!bytes.starts_with(b"\x89PNG\r\n\x1a\n"){return Err("Quadro PNG inválido ou acima de 24 MB.".into());}let w=u32::from_be_bytes(bytes[16..20].try_into().unwrap());let h=u32::from_be_bytes(bytes[20..24].try_into().unwrap());if w!=j.width||h!=j.height{return Err("Dimensões do PNG não correspondem à sessão.".into());}let p=j.frames.join(format!("frame_{index:06}.png"));fs::write(p,&bytes).map_err(|e|e.to_string())?;j.received+=1;Ok(json!({"ok":true,"received":j.received,"total":j.expected})) }
#[tauri::command] fn desktop_finish_video_session(app:tauri::AppHandle,state:State<'_,DesktopState>,token:String)->Result<serde_json::Value,String>{
 let mut map=state.videos.lock().map_err(|e|e.to_string())?;let j=map.get_mut(&token).ok_or("Sessão não encontrada.")?;if j.received!=j.expected{return Err(format!("Quadros incompletos: {}/{}.",j.received,j.expected));}if j.ready{return Err("Sessão já concluída.".into());}let (bin,_,_)=caps(&app)?;let mut cmd=Command::new(bin);cmd.args(["-y","-hide_banner","-loglevel","error","-framerate"]).arg(j.fps.to_string()).args(["-start_number","0","-i"]).arg(j.frames.join("frame_%06d.png")).args(["-frames:v"]).arg(j.expected.to_string()).arg("-an");cmd.args(format_args(&j.format)?).arg(&j.output);let out=cmd.output().map_err(|e|format!("Não foi possível iniciar FFmpeg: {e}"))?;if !out.status.success(){let detail=String::from_utf8_lossy(&out.stderr);return Err(format!("Falha na codificação {}: {}",j.format,detail.chars().take(1800).collect::<String>()));}if !j.output.is_file()||fs::metadata(&j.output).map(|m|m.len()).unwrap_or(0)==0{return Err("FFmpeg não gerou um arquivo válido.".into());}j.ready=true;let size=fs::metadata(&j.output).unwrap().len();let name=j.filename.clone();let fmt=j.format.clone();let frames=j.expected;let fps=j.fps;let root=j.root.clone();drop(map);let _=fs::remove_dir_all(root.join("frames"));Ok(json!({"ok":true,"token":token,"filename":name,"size":size,"codec":fmt,"frames":frames,"fps":fps})) }
#[tauri::command] fn desktop_cancel_video_session(state:State<'_,DesktopState>,token:String)->Result<serde_json::Value,String>{if let Some(j)=state.videos.lock().map_err(|e|e.to_string())?.remove(&token){let _=fs::remove_dir_all(j.root);}Ok(json!({"ok":true}))}
fn output_root(app: &tauri::AppHandle, requested: Option<String>) -> Result<PathBuf, String> {
    let path = match requested {
        Some(value) if !value.trim().is_empty() => PathBuf::from(value),
        _ => app.path().download_dir().map_err(|e| e.to_string())?,
    };
    if !path.is_absolute() { return Err("O diretório de saída precisa ser um caminho absoluto.".into()); }
    fs::create_dir_all(&path).map_err(|e| format!("Não foi possível criar o diretório de saída: {e}"))?;
    fs::canonicalize(&path).map_err(|e| format!("Não foi possível validar o diretório de saída: {e}"))
}
fn save_to_output(app: &tauri::AppHandle, src: &Path, relative: &str, output_dir: Option<String>) -> Result<String, String> {
    let root = output_root(app, output_dir)?;
    let rel = safe_rel(relative);
    if rel.is_empty() { return Err("O nome do arquivo de saída está vazio.".into()); }
    let dst = root.join(rel);
    if let Some(parent) = dst.parent() { fs::create_dir_all(parent).map_err(|e| format!("Não foi possível criar a subpasta de saída: {e}"))?; }
    fs::copy(src, &dst).map_err(|e| format!("Falha ao salvar arquivo: {e}"))?;
    Ok(dst.display().to_string())
}
#[tauri::command]
fn desktop_get_default_output_directory(app: tauri::AppHandle) -> Result<String, String> {
    let path = output_root(&app, None)?;
    Ok(path.display().to_string())
}
#[tauri::command]
async fn desktop_choose_output_directory(app: tauri::AppHandle, output_dir: Option<String>) -> Result<Option<String>, String> {
    let current = output_root(&app, output_dir)?;
    let selected = app.dialog().file().set_title("Escolher pasta de saída do RDV Bus").set_directory(current).blocking_pick_folder();
    match selected {
        Some(path) => {
            let path = path.into_path().map_err(|e| format!("Caminho selecionado inválido: {e}"))?;
            let path = output_root(&app, Some(path.display().to_string()))?;
            Ok(Some(path.display().to_string()))
        }
        None => Ok(None)
    }
}
#[tauri::command]
fn desktop_open_output_directory(app: tauri::AppHandle, output_dir: Option<String>) -> Result<(), String> {
    let path = output_root(&app, output_dir)?;
    #[cfg(target_os = "windows")]
    let mut command = { let mut c = Command::new("explorer"); c.arg(&path); c };
    #[cfg(target_os = "linux")]
    let mut command = { let mut c = Command::new("xdg-open"); c.arg(&path); c };
    #[cfg(target_os = "macos")]
    let mut command = { let mut c = Command::new("open"); c.arg(&path); c };
    command.spawn().map_err(|e| format!("Não foi possível abrir a pasta de saída: {e}"))?;
    Ok(())
}
#[tauri::command]
fn desktop_export_video(app: tauri::AppHandle, state: State<'_, DesktopState>, token: String, filename: Option<String>, folder: Option<String>, output_dir: Option<String>) -> Result<serde_json::Value, String> {
    let mut map = state.videos.lock().map_err(|e| e.to_string())?;
    let j = map.get(&token).ok_or("Vídeo temporário não encontrado.")?;
    if !j.ready { return Err("Vídeo ainda não está pronto.".into()); }
    let name = safe_name(filename.as_deref().unwrap_or(&j.filename));
    let relative = if let Some(folder) = folder.filter(|f| !f.is_empty()) { format!("{}/{}", safe_rel(&folder), name) } else { name.clone() };
    let dest = save_to_output(&app, &j.output, &relative, output_dir)?;
    let root = j.root.clone(); map.remove(&token); let _ = fs::remove_dir_all(root);
    Ok(json!({"ok":true,"filename":name,"location":dest}))
}
#[tauri::command]
fn desktop_create_package(app: tauri::AppHandle, state: State<'_, DesktopState>, filename: Option<String>) -> Result<serde_json::Value, String> {
    let token = Uuid::new_v4().simple().to_string(); let root = app_temp(&app,"package",&token)?;
    let filename = safe_name(filename.as_deref().unwrap_or("RDV_Bus_export.zip"));
    state.packages.lock().map_err(|e|e.to_string())?.insert(token.clone(),PackageJob{root,filename,items:Vec::new()});
    Ok(json!({"ok":true,"token":token}))
}
#[tauri::command]
fn desktop_add_package_blob(state: State<'_, DesktopState>, package_token: String, name: String, data: String) -> Result<serde_json::Value,String> {
    let bytes=B64.decode(data.split(',').last().unwrap_or(&data)).map_err(|e|e.to_string())?;
    if bytes.len()>24*1024*1024{return Err("Arquivo acima do limite de 24 MB.".into());}
    let mut map=state.packages.lock().map_err(|e|e.to_string())?;let j=map.get_mut(&package_token).ok_or("Pacote não encontrado.")?;
    let safe=safe_rel(&name);let p=j.root.join(format!("blob_{:05}.bin",j.items.len()));fs::write(&p,bytes).map_err(|e|e.to_string())?;j.items.push((safe,p));Ok(json!({"ok":true,"count":j.items.len()}))
}
#[tauri::command]
fn desktop_add_package_video(state: State<'_, DesktopState>, package_token: String, video_token: String, name: String) -> Result<serde_json::Value,String> {
    let mut packs=state.packages.lock().map_err(|e|e.to_string())?;let videos=state.videos.lock().map_err(|e|e.to_string())?;
    let v=videos.get(&video_token).ok_or("Vídeo não encontrado.")?;if !v.ready{return Err("Vídeo ainda não foi codificado.".into());}
    let p=packs.get_mut(&package_token).ok_or("Pacote não encontrado.")?;p.items.push((safe_rel(&name),v.output.clone()));Ok(json!({"ok":true,"count":p.items.len()}))
}
#[tauri::command]
fn desktop_finish_package(app: tauri::AppHandle, state: State<'_, DesktopState>, package_token: String, output_dir: Option<String>) -> Result<serde_json::Value,String> {
    let mut packs=state.packages.lock().map_err(|e|e.to_string())?;let j=packs.remove(&package_token).ok_or("Pacote não encontrado.")?;
    if j.items.is_empty(){return Err("Pacote vazio.".into());}
    let zip_path=j.root.join(&j.filename);let file=File::create(&zip_path).map_err(|e|e.to_string())?;let mut zip=ZipWriter::new(file);
    let opts=SimpleFileOptions::default().compression_method(zip::CompressionMethod::Deflated);
    for (name,path) in &j.items { zip.start_file(name.replace('\\',"/"),opts).map_err(|e|e.to_string())?;let mut f=File::open(path).map_err(|e|e.to_string())?;let mut buf=[0u8;131072];loop{let n=f.read(&mut buf).map_err(|e|e.to_string())?;if n==0{break;}zip.write_all(&buf[..n]).map_err(|e|e.to_string())?;} }
    zip.finish().map_err(|e|e.to_string())?;
    let dest=save_to_output(&app,&zip_path,&j.filename,output_dir)?;
    {let mut videos=state.videos.lock().map_err(|e|e.to_string())?;let tokens:Vec<String>=videos.iter().filter(|(_,v)|j.items.iter().any(|(_,p)|p==&v.output)).map(|(k,_)|k.clone()).collect();for t in tokens{if let Some(v)=videos.remove(&t){let _=fs::remove_dir_all(v.root);}}}
    let size=fs::metadata(&dest).map(|m|m.len()).unwrap_or(0);let _=fs::remove_dir_all(j.root);
    Ok(json!({"ok":true,"filename":j.filename,"size":size,"location":dest}))
}
#[tauri::command]
fn desktop_cancel_package(state: State<'_, DesktopState>, package_token: String) -> Result<serde_json::Value,String> {
    if let Some(j)=state.packages.lock().map_err(|e|e.to_string())?.remove(&package_token){let _=fs::remove_dir_all(j.root);}Ok(json!({"ok":true}))
}
#[tauri::command]
fn desktop_save_blob(app: tauri::AppHandle, filename: String, data: String, output_dir: Option<String>) -> Result<serde_json::Value,String> {
    let bytes=B64.decode(data.split(',').last().unwrap_or(&data)).map_err(|e|e.to_string())?;
    if bytes.len()>24*1024*1024{return Err("Arquivo acima do limite de 24 MB.".into());}
    let temp=app.path().app_cache_dir().map_err(|e|e.to_string())?.join("rdv-native").join("single").join(Uuid::new_v4().simple().to_string());
    fs::create_dir_all(&temp).map_err(|e|e.to_string())?;
    let relative=safe_rel(&filename);let p=temp.join(safe_name(&relative));fs::write(&p,bytes).map_err(|e|e.to_string())?;
    let dest=save_to_output(&app,&p,&relative,output_dir)?;let _=fs::remove_dir_all(temp);
    Ok(json!({"ok":true,"filename":filename,"location":dest}))
}

fn main(){tauri::Builder::default().plugin(tauri_plugin_dialog::init()).manage(DesktopState::default()).invoke_handler(tauri::generate_handler![diagnose_runtime,desktop_get_capabilities,desktop_create_video_session,desktop_add_frame,desktop_finish_video_session,desktop_cancel_video_session,desktop_export_video,desktop_create_package,desktop_add_package_blob,desktop_add_package_video,desktop_finish_package,desktop_cancel_package,desktop_save_blob,desktop_get_default_output_directory,desktop_choose_output_directory,desktop_open_output_directory]).run(tauri::generate_context!()).expect("erro ao iniciar RDV Bus Desktop");}
