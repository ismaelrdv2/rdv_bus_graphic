# Diagnóstico de dependências — RDV Bus Desktop 0.13.4

O backend Tauri oferece `diagnose_runtime`, e a interface consulta `desktop_get_capabilities` pela ponte nativa. A detecção do Tauri 2 usa a presença de `window.__TAURI_INTERNALS__`, que é o marcador usado pelo runtime IPC.

## O que é verificado
- Inicialização do WebView e da ponte JavaScript/Rust.
- Localização e execução do FFmpeg. Em desenvolvimento e em builds release, aceita `RDV_FFMPEG_PATH` ou o executável `ffmpeg`/`ffmpeg.exe` disponível no `PATH`. O FFmpeg não é incorporado ao instalador Desktop.
- Codificadores `qtrle`, `prores_ks`, `png`, `ffv1` e `libvpx-vp9`.
- Falhas de consulta são exibidas no status de exportação e registradas no Console, em vez de serem descartadas silenciosamente.

## Dependências do sistema
- **Windows:** o instalador NSIS está configurado para baixar o bootstrapper do Microsoft Edge WebView2 Runtime quando necessário. A versão portátil exige WebView2 previamente instalado.
- **Linux/AppImage:** Tauri usa WebKitGTK 4.1 do sistema. Se a biblioteca estiver ausente ou incompatível, o processo pode falhar antes de abrir a interface. O AppImage não é totalmente independente de WebKitGTK.
- **FFmpeg:** a distribuição final deverá incluir o binário compatível com a plataforma e os codificadores necessários. FFmpeg do sistema é apenas um fallback para desenvolvimento.

## HMR/Vite
O Vite escuta em `127.0.0.1:5173` e o `devUrl` do Tauri usa o mesmo endereço. Falhas de WebSocket HMR podem prejudicar atualização automática durante desenvolvimento, mas não são a causa da comunicação de comandos IPC Rust/JavaScript.

## Iniciadores de pré-verificação
- `scripts/rdv-bus-preflight-linux.sh` verifica bibliotecas WebKitGTK 4.1 / JavaScriptCoreGTK 4.1 / GTK 3 antes de abrir o AppImage.
- `scripts/RDV-Bus-Portable-Windows.cmd` verifica o WebView2 Runtime antes de abrir `RDV-Bus.exe` no pacote portátil.
